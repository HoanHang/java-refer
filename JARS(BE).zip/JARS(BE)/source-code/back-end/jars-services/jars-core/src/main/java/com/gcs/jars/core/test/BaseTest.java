package com.gcs.jars.core.test;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gcs.jars.core.dto.SearchResultDTO;
import com.gcs.jars.core.dto.SerializableDTO;

public abstract class BaseTest {

    /**
     * Map to json.
     *
     * @param obj
     *            the obj
     * @return the string
     * @throws JsonProcessingException
     *             the json processing exception
     */
    protected String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }

    /**
     * Map from json.
     *
     * @param <T>
     *            the generic type
     * @param json
     *            the json
     * @param clazz
     *            the clazz
     * @return the t
     * @throws JsonParseException
     *             the json parse exception
     * @throws JsonMappingException
     *             the json mapping exception
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    protected <T> T mapFromJson(String json, Class<T> clazz)
            throws JsonParseException, JsonMappingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(json, clazz);
    }

    /**
     * Map from json.
     *
     * @param <T>
     *            the generic type
     * @param json
     *            the json
     * @return the t[]
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    protected <T> List<T> mapFromJson(String json) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        TypeReference<List<T>> typeReference = new TypeReference<List<T>>() {
        };
        return objectMapper.readValue(json, typeReference);
    }

    /**
     * To list.
     *
     * @param <E>
     *            the element type
     * @param object
     *            the object
     * @param clz
     *            the clz
     * @return the list
     */
    @SuppressWarnings("unchecked")
    protected <E> List<E> toList(Object object) {
        try {
            List<E> data = (List<E>) object;
            return data;
        } catch (Exception ex) {
            return null;
        }
    }
    
    /**
     * To search result.
     *
     * @param <E> the element type
     * @param object the object
     * @return the search result DTO
     */
    @SuppressWarnings("unchecked")
    protected <E extends SerializableDTO> SearchResultDTO<E> toSearchResult(Object object) {
        try {
            SearchResultDTO<E> data = (SearchResultDTO<E>) object;
            return data;
        } catch (Exception ex) {
            return null;
        }
    }
}
