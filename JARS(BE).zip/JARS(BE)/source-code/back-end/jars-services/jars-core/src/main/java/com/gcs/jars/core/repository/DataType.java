package com.gcs.jars.core.repository;

public class DataType {
    public static final String NUMBER = "number";
    public static final String DATE = "date";
    public static final String DATETIME = "datetime";
}
