package com.gcs.jars.core.repository;

import java.io.Serializable;

import org.springframework.data.domain.Page;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class SearchResult<T> implements Serializable {
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8889916279528418133L;

    /** The items. */
    private Page<T> page;
    
    /** The total items. */
    private Long totalItems;
}
