/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.service;

import java.util.List;

import com.gcs.jars.core.converter.BaseConverter;
import com.gcs.jars.core.dto.BaseDTO;
import com.gcs.jars.core.dto.SearchResultDTO;
import com.gcs.jars.core.entity.BaseEntity;
import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.core.repository.SearchCondition;

public interface BaseDataService<TId, TEntity extends BaseEntity<TId>, TDto extends BaseDTO<TId>, TRepo extends BaseRepository<TEntity, TId>, TCvt extends BaseConverter<TEntity, TDto>> {

    /**
     * Gets the entity name.
     *
     * @return the entity name
     */
    String getEntityName();
    
    /**
     * Find all.
     *
     * @return the list
     */
    List<TDto> findAll();

    /**
     * Find by criteria.
     *
     * @param searchCondition the search condition
     * @return the list
     */
    SearchResultDTO<TDto> findByCriteria(SearchCondition searchCondition);

    /**
     * Find by id.
     *
     * @param id
     *            the id
     * @return the t entity
     */
    TDto findById(TId id);

    /**
     * Insert.
     *
     * @param dto
     *            the dto
     */
    TDto insert(TDto dto);
    
    /**
     * Insert batch.
     *
     * @param dtoList the dto list
     * @return the list
     */
    List<TDto> insertBatch(List<TDto> dtoList);

    /**
     * Update.
     *
     * @param dto the dto
     */
    TDto update(TDto dto);

    /**
     * Delete.
     *
     * @param id
     *            the id
     */
    void delete(TId id);
    
    /**
     * Delete Many
     * @param listDTO
     */
    void deleteList(List<TDto> listDTO);
    
    /**
     * Update List
     * @param listDTO
     */
    void updateList(List<TDto> listDTO);
}
