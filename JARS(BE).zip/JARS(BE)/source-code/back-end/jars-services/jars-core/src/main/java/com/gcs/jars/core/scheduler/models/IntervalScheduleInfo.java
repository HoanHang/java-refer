package com.gcs.jars.core.scheduler.models;

import org.quartz.Job;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IntervalScheduleInfo<TJob extends Job> extends BaseScheduleInfo<TJob> {
    
    /** The interval second. */
    private Integer intervalSecond;
}
