package com.gcs.jars.core.executor;

import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import com.gcs.jars.constant.ErrorCodes;
import com.gcs.jars.constant.core.CommonConstants;
import com.gcs.jars.core.exception.UserDefinedException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CountDownJobExecutor {

    /**
     * Execute.
     *
     * @param <T>
     *            the generic type
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     * @param numThread
     *            the num thread
     * @param logCountDownInfo
     *            the log count down info
     */
    public static <T> void execute(String taskName, List<T> list, Consumer<T> consumer, Integer numThread,
            Boolean logCountDownInfo) {
        final ExecutorService taskExecutor = Executors.newFixedThreadPool(numThread);
        doExecute(taskExecutor, taskName, list, consumer, logCountDownInfo);
    }

    /**
     * Execute.
     *
     * @param <T>
     *            the generic type
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     */
    public static <T> void execute(String taskName, List<T> list, Consumer<T> consumer, Integer numThread) {
        final ExecutorService taskExecutor = Executors.newFixedThreadPool(numThread);
        doExecute(taskExecutor, taskName, list, consumer, false);
    }

    /**
     * Execute.
     *
     * @param <T>
     *            the generic type
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     */
    public static <T> void execute(String taskName, List<T> list, Consumer<T> consumer, Boolean logCountDownInfo) {
        final ExecutorService taskExecutor = Executors.newFixedThreadPool(CommonConstants.NUM_THREADS);
        doExecute(taskExecutor, taskName, list, consumer, logCountDownInfo);
    }

    /**
     * Execute.
     *
     * @param <T>
     *            the generic type
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     */
    public static <T> void execute(String taskName, List<T> list, Consumer<T> consumer) {
        final ExecutorService taskExecutor = Executors.newFixedThreadPool(CommonConstants.NUM_THREADS);
        doExecute(taskExecutor, taskName, list, consumer, false);
    }

    /**
     * Execute seq.
     *
     * @param <T>
     *            the generic type
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     */
    public static <T> void executeSeq(String taskName, List<T> list, Consumer<T> consumer, Boolean logCountDownInfo) {
        final ExecutorService taskExecutor = Executors.newSingleThreadExecutor();
        doExecute(taskExecutor, taskName, list, consumer, logCountDownInfo);
    }

    /**
     * Execute seq.
     *
     * @param <T>
     *            the generic type
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     */
    public static <T> void executeSeq(String taskName, List<T> list, Consumer<T> consumer) {
        final ExecutorService taskExecutor = Executors.newSingleThreadExecutor();
        doExecute(taskExecutor, taskName, list, consumer, false);
    }

    /**
     * Do execute.
     *
     * @param <T>
     *            the generic type
     * @param taskExecutor
     *            the task executor
     * @param taskName
     *            the task name
     * @param list
     *            the list
     * @param consumer
     *            the consumer
     */
    private static <T> void doExecute(ExecutorService taskExecutor, String taskName, List<T> list, Consumer<T> consumer,
            Boolean logCountDownInfo) {
        log.info("{} - TOTAL=[{}]...", taskName, list.size());
        final CountDownLatch latch = new CountDownLatch(list.size());
        list.stream().forEach(item -> {
            taskExecutor.submit(() -> {
                try {
                    consumer.accept(item);
                } catch (Exception e) {
                    log.error("{} - failed to execute task, count=[{}], error: {}", taskName, latch.getCount(), e);
                } finally {
                    latch.countDown();
                    if (logCountDownInfo) {
                        log.info("{} - COUNT=[{}]", taskName, latch.getCount());
                    } else {
                        log.debug("{} - COUNT=[{}]", taskName, latch.getCount());
                    }
                }
            });
        });
        try {
            latch.await();
            taskExecutor.shutdown();
        } catch (InterruptedException e) {
            String errorMsg = String.format("%s - failed to parallel execute", taskName);
            log.error(errorMsg, e);
            throw new UserDefinedException(ErrorCodes.ERROR_UNKNOW, errorMsg);
        }
        log.info("{} - TOTAL=[{}]...DONE", taskName, list.size());
    }
}
