/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class UserDefinedException.
 */
@NoArgsConstructor
@Getter
@Setter
public class UserDefinedException extends RuntimeException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7252949981915663662L;

    /** The error code. */
    private String errorCode;
    
    /** The is handled. */
    private Boolean isHandled;

    /**
     * Instantiates a new base exception.
     *
     * @param errorCode
     *            the error code
     * @param errorText
     *            the error text
     */
    public UserDefinedException(final String errorCode, final String errorText) {
        super(errorText);
        this.errorCode = errorCode;
        this.isHandled = false;
    }

    /**
     * Instantiates a new base exception.
     *
     * @param errorCode
     *            the error code
     * @param errorText
     *            the error text
     * @param cause
     *            the cause
     */
    public UserDefinedException(final String errorCode, final String errorText, final Throwable cause) {
        super(errorText, cause);
        this.errorCode = errorCode;
        this.isHandled = false;
    }
}
