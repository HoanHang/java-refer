package com.gcs.jars.core.processflow;

import java.util.function.Consumer;

public interface ProcessStep {
    
    /**
     * Gets the name.
     *
     * @return the name
     */
    String getName();
    
    /**
     * Execute.
     */
    ProcessResult execute();

    /**
     * Register exception handling.
     *
     * @param onException the on exception
     * @return the process step
     */
    ProcessStep registerOnException(Consumer<Exception> onException);
}
