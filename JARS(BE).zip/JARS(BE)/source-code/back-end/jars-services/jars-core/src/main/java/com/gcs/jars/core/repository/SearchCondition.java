/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.repository;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SearchCondition.
 */
@Setter
@Getter
@NoArgsConstructor
public class SearchCondition implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7414289465365231673L;

    /** The conditions. */
    private List<Condition> conditions = new ArrayList<>();

    /** The page. */
    private Integer page;

    /** The size. */
    private Integer size;

    /** The sort name. */
    private String sortName;

    /** The sort direction. */
    private Boolean sortDirection;
}
