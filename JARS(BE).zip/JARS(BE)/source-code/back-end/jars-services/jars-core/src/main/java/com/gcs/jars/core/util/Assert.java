/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.util;

import com.gcs.jars.constant.core.CommonErrorCodes;
import com.gcs.jars.core.exception.NotFoundException;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class Assert {

    /**
     * Not null.
     *
     * @param <TId>
     *            the generic type
     * @param object
     *            the object
     * @param id
     *            the id
     * @throws NotFoundException
     *             the jars not found exception
     */
    public static <TId> void notNull(Object object, TId id) {
        if (object == null) {
            String message = String.format("Not found item with specified ID=[%s]", id.toString());
            throw new NotFoundException(CommonErrorCodes.NOT_FOUND, message);
        }
    }
}
