/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.tuple.Pair;
import org.springframework.beans.factory.annotation.Autowired;

import com.gcs.jars.core.converter.BaseConverter;
import com.gcs.jars.core.dto.BaseDTO;
import com.gcs.jars.core.dto.SearchResultDTO;
import com.gcs.jars.core.entity.BaseEntity;
import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.core.util.Assert;
import com.gcs.jars.core.util.CollectionUtil;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor
public abstract class BaseDataServiceImpl<TId, TEntity extends BaseEntity<TId>, TDto extends BaseDTO<TId>, TRepo extends BaseRepository<TEntity, TId>, TCvt extends BaseConverter<TEntity, TDto>>
        implements BaseDataService<TId, TEntity, TDto, TRepo, TCvt> {

    /** The repository. */
    @Autowired
    protected TRepo repository;

    /** The converter. */
    @Autowired
    protected TCvt converter;

    /**
     * Gets the entity name.
     *
     * @return the entity name
     */
    public abstract String getEntityName();

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#findAll()
     */
    @InjectLog(logParams = false)
    public List<TDto> findAll() {
        List<TDto> dtoList = new ArrayList<>();
        List<TEntity> entityList = this.repository.findAll();
        if (!CollectionUtil.isNullOrEmpty(entityList)) {
            log.debug("findAll - num_entities=[{}]", entityList.size());
            for (TEntity entity : entityList) {
                TDto dto = this.converter.toDto(entity);
                dtoList.add(dto);
            }
        }
        return dtoList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#findByCriteria(com.gcs.jars.core.repository.SearchCondition)
     */
    @InjectLog(logParams = false)
    public SearchResultDTO<TDto> findByCriteria(SearchCondition searchCondition) {
        SearchResultDTO<TDto> searchResult = new SearchResultDTO<TDto>();
        SearchResult<TEntity> entityPage = this.repository.findByCriteria(searchCondition);
        List<TEntity> entityList = entityPage.getPage().getContent();
        if (!CollectionUtil.isNullOrEmpty(entityList)) {
            searchResult.setTotalItems(entityPage.getTotalItems());
            List<TDto> dtoList = new ArrayList<>();
            for (TEntity entity : entityList) {
                TDto dto = this.converter.toDto(entity);
                dtoList.add(dto);
            }
            this.updateRelations(searchCondition, entityList, dtoList);
            searchResult.setItems(dtoList);
        }
        return searchResult;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#findById(java.lang.Object)
     */
    @InjectLog(logParams = false)
    public TDto findById(TId id) {
        TDto dto = null;
        TEntity entity = this.repository.findByIdentifier(id);
        if (entity != null) {
            dto = this.converter.toDto(entity);
        }
        return dto;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#insert(java.lang.Object)
     */
    @InjectLog(logParams = false)
    public TDto insert(TDto dto) {
        TEntity entity = this.converter.toEntity(dto);
        TEntity savedEntity = this.repository.save(entity);
        return this.converter.toDto(savedEntity);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#insertBatch(java.util.List)
     */
    @InjectLog(logParams = false)
    public List<TDto> insertBatch(List<TDto> dtoList) {
        List<TEntity> entityList = new ArrayList<TEntity>();
        for (TDto dto : dtoList) {
            TEntity entity = this.converter.toEntity(dto);
            entityList.add(entity);
        }
        List<TDto> savedDtoList = new ArrayList<TDto>();
        List<TEntity> savedEntityList = this.repository.saveAll(entityList);
        for (TEntity entity : savedEntityList) {
            TDto dto = this.converter.toDto(entity);
            savedDtoList.add(dto);
        }
        return savedDtoList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#update(com.gcs.jars.dto.base.BaseDTO)
     */
    @InjectLog(logParams = false)
    public TDto update(TDto dto) {
        TId id = dto.getIdentifier();
        TEntity entity = this.repository.findByIdentifier(id);
        Assert.notNull(entity, id);

        this.converter.toEntity(dto, entity);
        TEntity savedEntity = this.repository.save(entity);
        return this.converter.toDto(savedEntity);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#delete(java.lang.Object)
     */
    @InjectLog(logParams = false)
    public void delete(TId id) {
        this.repository.deleteById(id);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#delete(java.lang.Object)
     */
    @InjectLog(logParams = false)
    public void deleteList(List<TDto> listDTO) {
        if (!CollectionUtil.isNullOrEmpty(listDTO)) {
            for (int i = 0; i < listDTO.size(); i++) {
                this.repository.deleteById(listDTO.get(i).getIdentifier());
            }
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.service.BaseDataService#updateList(java.util.List)
     */
    @InjectLog(logParams = false)
    public void updateList(List<TDto> listDTO) {
        if (!CollectionUtil.isNullOrEmpty(listDTO)) {
            for (int i = 0; i < listDTO.size(); i++) {
                this.repository.save(this.converter.toEntity(listDTO.get(i)));
            }
        }
    }

    /**
     * Update relations.
     *
     * @param searchCondition
     *            the search condition
     * @param entityList
     *            the entity list
     * @param dtoList
     *            the dto list
     */
    protected void updateRelations(SearchCondition searchCondition, List<TEntity> entityList, List<TDto> dtoList) {
        // Implement by concrete classes
    }

    /**
     * Find criteria.
     *
     * @param searchCondition
     *            the search condition
     * @param key
     *            the key
     * @return the pair
     */
    protected Pair<Boolean, Object> findCriteria(SearchCondition searchCondition, String key) {
        Pair<Boolean, Object> criteria = Pair.of(false, null);
        for (Condition condition : searchCondition.getConditions()) {
            if (condition.getKey().equalsIgnoreCase(key)) {
                criteria = Pair.of(true, condition.getValue());
                break;
            }
        }
        return criteria;
    }

    /**
     * Builds the ref map.
     *
     * @param <TRef>
     *            the generic type
     * @param <TRefRepo>
     *            the generic type
     * @param searchCondition
     *            the search condition
     * @param refName
     *            the ref name
     * @param refRepository
     *            the repository
     * @return the map
     */
    protected <TRef, TRefRepo extends BaseRepository<TRef, Integer>> Map<Integer, TRef> buildRefMap(
            SearchCondition searchCondition, String refName, TRefRepo refRepository) {
        Map<Integer, TRef> refMap = new HashMap<Integer, TRef>();
        Pair<Boolean, Object> refCriteria = this.findCriteria(searchCondition, refName);
        if (refCriteria.getLeft()) { // Found
            String searchValue = refCriteria.getRight().toString();
            List<String> searchValueList = this.createValueList(searchValue);
            for (String value : searchValueList) {
                Integer refId = Integer.parseInt(value);
                if (!refMap.containsKey(refId)) {
                    refMap.put(refId, refRepository.findByIdentifier(refId));
                }
            }
        }
        return refMap;
    }

    /**
     * Creates the value list.
     *
     * @param value
     *            the value
     * @return the list
     */
    protected List<String> createValueList(String value) {
        List<String> valueList = null;
        if (value.contains(",")) {
            valueList = Arrays.asList(value.split(",")).stream().map(n -> n.trim()).collect(Collectors.toList());
        } else {
            valueList = new ArrayList<>();
            valueList.add(value);
        }
        return valueList;
    }
}
