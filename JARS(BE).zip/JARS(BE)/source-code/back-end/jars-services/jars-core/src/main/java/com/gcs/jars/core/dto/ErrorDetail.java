/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonInclude(Include.NON_NULL)
@Getter
@Setter
@ToString
public class ErrorDetail {

    /** The code. */
    private String code;

    /** The message. */
    private String message;

    /**
     * Instantiates a new error detail.
     *
     * @param code
     *            the code
     */
    public ErrorDetail(String code) {
        super();
        this.code = code;
    }

    /**
     * Instantiates a new error detail.
     *
     * @param code
     *            the code
     * @param message
     *            the message
     */
    public ErrorDetail(String code, String message) {
        super();
        this.code = code;
        this.message = message;
    }
}
