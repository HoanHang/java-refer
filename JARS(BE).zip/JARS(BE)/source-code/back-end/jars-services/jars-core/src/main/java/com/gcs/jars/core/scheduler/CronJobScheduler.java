package com.gcs.jars.core.scheduler;

import static org.quartz.TriggerBuilder.newTrigger;

import java.util.Date;
import java.util.TimeZone;

import org.quartz.CronScheduleBuilder;
import org.quartz.Job;
import org.quartz.Trigger;

import com.gcs.jars.core.scheduler.models.CronScheduleInfo;
import com.gcs.jars.core.util.DateTimeUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class CronJobScheduler<TJob extends Job, TScheduleInfo extends CronScheduleInfo<TJob>>
        extends BaseJobScheduler<TJob, TScheduleInfo> {

    /**
     * Creates the trigger.
     *
     * @param <TJob>
     *            the generic type
     * @param scheduleInfo
     *            the schedule info
     * @param triggerName
     *            the trigger name
     * @param triggerGroup
     *            the trigger group
     * @return the trigger
     */
    protected Trigger createTrigger(TScheduleInfo scheduleInfo, String triggerName, String triggerGroup) {
        String cronTime = this.createCronTime(scheduleInfo);
        log.info("createTrigger - cronTime=[{}], timeZone=[{}], currentTime=[{}]", cronTime, scheduleInfo.getTimeZone(),
                DateTimeUtil.toString(new Date()));
        Trigger trigger = newTrigger().withIdentity(triggerName, triggerGroup).withSchedule(
                CronScheduleBuilder.cronSchedule(cronTime).inTimeZone(TimeZone.getTimeZone(scheduleInfo.getTimeZone())))
                .build();
        return trigger;
    }

    /**
     * Creates the cron time.
     * https://www.freeformatter.com/cron-expression-generator-quartz.html
     *
     * @param schedule
     *            the schedule
     * @return the string
     */
    protected String createCronTime(TScheduleInfo schedule) {
        return String.format("%d %d %d/%d ? * * *", schedule.getSeconds(), schedule.getMinutes(), schedule.getHours(),
                schedule.getIntervalHours());
    }
}
