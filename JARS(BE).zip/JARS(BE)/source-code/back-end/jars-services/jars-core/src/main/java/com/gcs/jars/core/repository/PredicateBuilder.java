package com.gcs.jars.core.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.apache.commons.lang3.StringUtils;

import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.core.util.CollectionUtil;
import com.gcs.jars.core.util.DateTimeUtil;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class PredicateBuilder {

    /**
     * Builds the.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param searchCondition
     *            the search condition
     * @return the list
     */
    @InjectLog(logParams = false)
    public static <T> List<Predicate> build(Root<T> root, CriteriaBuilder criteriaBuilder,
            SearchCondition searchCondition) {
        List<Predicate> predicates = new ArrayList<>(searchCondition.getConditions().size());
        log.debug("build - num_conditions=[{}]", searchCondition.getConditions().size());
        // Predicate for conditions without join
        List<Condition> withoutJoinConditions = filterConditionsWithoutJoin(searchCondition);
        if (!CollectionUtil.isNullOrEmpty(withoutJoinConditions)) {
            buildPredicateWithConditions(root, criteriaBuilder, withoutJoinConditions, predicates);
        }
        // Predicate for conditions with join
        List<Condition> withJoinConditions = filterConditionsWithJoin(searchCondition);
        if (!CollectionUtil.isNullOrEmpty(withJoinConditions)) {
            Map<String, List<Condition>> groupJoinConditions = groupConditionsByJoinTable(withJoinConditions);
            groupJoinConditions.forEach((k, v) -> {
                List<Condition> conditions = v;
                String joinTable = k;
                String joinType = v.get(0).getJoinType();
                Join< ? , ? > rootAfterJoin = createTableJoins(root, joinTable, joinType);
                buildPredicateWithConditions(rootAfterJoin, criteriaBuilder, conditions, predicates);
            });
        }
        return predicates;
    }

    /**
     * Builds the predicate with conditions.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param conditionList
     *            the condition list
     * @param predicates
     *            the predicates
     */
    private static <T> void buildPredicateWithConditions(From< ? , ? > root, CriteriaBuilder criteriaBuilder,
            List<Condition> conditionList, List<Predicate> predicates) {
        for (Condition condition : conditionList) {
            Predicate predicate = null;
            String key = condition.getKey();
            Object value = condition.getValue();
            String dataType = condition.getType();
            String operator = condition.getOperator();
            String joinTable = condition.getJoinTable();
            String joinType = condition.getJoinType();
            log.debug("build - key=[{}], value=[{}], dataType=[{}], operator=[{}], joinTable=[{}], joinType=[{}]", key,
                    value, dataType, operator, joinTable, joinType);
            switch (operator) {
            case Operator.EQUAL_IN:
                predicate = buildEqualIn(root, criteriaBuilder, key, value);
                break;
            case Operator.NOT_EQUAL_IN:
                predicate = buildNotEqualIn(root, criteriaBuilder, key, value);
                break;
            case Operator.LIKE_IN:
                predicate = buildLikeIn(root, criteriaBuilder, key, value);
                break;
            case Operator.EQUAL:
                predicate = buildEqual(root, criteriaBuilder, key, value);
                break;
            case Operator.NOT_EQUAL:
                predicate = buildNotEqual(root, criteriaBuilder, key, value);
                break;
            case Operator.LIKE:
                predicate = buildLike(root, criteriaBuilder, key, value);
                break;
            case Operator.NOT_LIKE:
                predicate = buildNotLike(root, criteriaBuilder, key, value);
                break;
            case Operator.LESS_THAN:
                predicate = buildLessThan(root, criteriaBuilder, key, value, dataType);
                break;
            case Operator.LESS_OR_EQUAL:
                predicate = buildLessOrEqual(root, criteriaBuilder, key, value, dataType);
                break;
            case Operator.GREATER_THAN:
                predicate = buildGreaterThan(root, criteriaBuilder, key, value, dataType);
                break;
            case Operator.GREATER_OR_EQUAL:
                predicate = buildGreaterOrEqual(root, criteriaBuilder, key, value, dataType);
                break;
            case Operator.IS_NULL:
                predicate = buildIsNull(root, criteriaBuilder, key, value);
                break;
            case Operator.IS_NOT_NULL:
                predicate = buildIsNotNull(root, criteriaBuilder, key, value);
                break;
            default:
            }
            if (predicate != null) {
                predicates.add(predicate);
            }
        }
    }

    /**
     * Filter conditions without join.
     *
     * @param searchCondition
     *            the search condition
     * @return the list
     */
    private static List<Condition> filterConditionsWithoutJoin(SearchCondition searchCondition) {
        return searchCondition.getConditions().stream().filter(n -> StringUtils.isBlank(n.getJoinTable()))
                .collect(Collectors.toList());
    }

    /**
     * Filter conditions with join.
     *
     * @param searchCondition
     *            the search condition
     * @return the list
     */
    private static List<Condition> filterConditionsWithJoin(SearchCondition searchCondition) {
        return searchCondition.getConditions().stream().filter(n -> !StringUtils.isBlank(n.getJoinTable()))
                .collect(Collectors.toList());
    }

    /**
     * Group conditions by join table.
     *
     * @param conditions
     *            the conditions
     * @return the map
     */
    private static Map<String, List<Condition>> groupConditionsByJoinTable(List<Condition> conditions) {
        return conditions.stream().collect(Collectors.groupingBy(n -> n.getJoinTable()));
    }

    /**
     * Builds the count greater or equal.
     *
     * @param <T>
     *            the generic type
     * @param <TJoin>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param criteriaQuery
     *            the criteria query
     * @param searchCondition
     *            the search condition
     * @param condition
     *            the condition
     * @param typeofTJoin
     *            the typeof T join
     * @return the predicate
     */
    @InjectLog(logParams = false)
    public static <T, TJoin> Predicate buildCountGreaterOrEqual(Root<T> root, CriteriaBuilder criteriaBuilder,
            CriteriaQuery< ? > criteriaQuery, SearchCondition searchCondition, Condition condition,
            Class<TJoin> typeofTJoin) {
        String key = condition.getKey();
        Object value = condition.getValue();
        String dataType = condition.getType();
        String operator = condition.getOperator();
        log.debug("buildCountGreaterOrEqual - key=[{}], value=[{}], dataType=[{}], operator=[{}]", key, value, dataType,
                operator);
        Subquery<Long> subQuery = criteriaQuery.subquery(Long.class);
        Root<TJoin> rootCount = subQuery.from(typeofTJoin);
        subQuery.where(criteriaBuilder.equal(rootCount.get(key), root.get(key)));
        return criteriaBuilder.ge(subQuery.select(criteriaBuilder.count(rootCount)), (Number) value);
    }

    /**
     * Builds the equal.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildEqual(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = criteriaBuilder.equal(root.get(key), value);
        return predicate;
    }

    /**
     * Builds the not equal.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildNotEqual(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = criteriaBuilder.notEqual(root.get(key), value);
        return predicate;
    }

    /**
     * Builds the like.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildLike(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = criteriaBuilder.like(root.get(key), "%" + value + "%");
        return predicate;
    }

    /**
     * Builds the not like.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildNotLike(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = criteriaBuilder.notLike(root.get(key), "%" + value + "%");
        return predicate;
    }

    /**
     * Builds the less than.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @param dataType
     *            the data type
     * @return the predicate
     */
    private static <T> Predicate buildLessThan(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value, String dataType) {
        Predicate predicate = null;
        switch (dataType) {
        case DataType.NUMBER:
            predicate = criteriaBuilder.lt(root.get(key), (Number) value);
            break;
        case DataType.DATE: {
            Date date = DateTimeUtil.toDate(value.toString());
            predicate = criteriaBuilder.lessThan(root.get(key), date);
            break;
        }
        case DataType.DATETIME: {
            Date date = DateTimeUtil.toDateTime(value.toString());
            predicate = criteriaBuilder.lessThan(root.get(key), date);
            break;
        }
        default:
            break;
        }
        return predicate;
    }

    /**
     * Builds the less or equal.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @param dataType
     *            the data type
     * @return the predicate
     */
    private static <T> Predicate buildLessOrEqual(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value, String dataType) {
        Predicate predicate = null;
        switch (dataType) {
        case DataType.NUMBER:
            predicate = criteriaBuilder.le(root.get(key), (Number) value);
            break;
        case DataType.DATE: {
            Date date = DateTimeUtil.toDate(value.toString());
            predicate = criteriaBuilder.lessThanOrEqualTo(root.get(key), date);
            break;
        }
        case DataType.DATETIME: {
            Date date = DateTimeUtil.toDateTime(value.toString());
            predicate = criteriaBuilder.lessThanOrEqualTo(root.get(key), date);
            break;
        }
        default:
            break;
        }
        return predicate;
    }

    /**
     * Builds the greater than.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @param dataType
     *            the data type
     * @return the predicate
     */
    private static <T> Predicate buildGreaterThan(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value, String dataType) {
        Predicate predicate = null;
        switch (dataType) {
        case DataType.NUMBER:
            predicate = criteriaBuilder.gt(root.get(key), (Number) value);
            break;
        case DataType.DATE: {
            Date date = DateTimeUtil.toDate(value.toString());
            predicate = criteriaBuilder.greaterThan(root.get(key), date);
            break;
        }
        case DataType.DATETIME: {
            Date date = DateTimeUtil.toDateTime(value.toString());
            predicate = criteriaBuilder.greaterThan(root.get(key), date);
            break;
        }
        default:
            break;
        }
        return predicate;
    }

    /**
     * Builds the greater or equal.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @param dataType
     *            the data type
     * @return the predicate
     */
    private static <T> Predicate buildGreaterOrEqual(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value, String dataType) {
        Predicate predicate = null;
        switch (dataType) {
        case DataType.NUMBER:
            predicate = criteriaBuilder.ge(root.get(key), (Number) value);
            break;
        case DataType.DATE: {
            Date date = DateTimeUtil.toDate(value.toString());
            predicate = criteriaBuilder.greaterThanOrEqualTo(root.get(key), date);
            break;
        }
        case DataType.DATETIME: {
            Date date = DateTimeUtil.toDateTime(value.toString());
            predicate = criteriaBuilder.greaterThanOrEqualTo(root.get(key), date);
            break;
        }
        default:
            break;
        }
        return predicate;
    }

    /**
     * Builds the equal in.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildEqualIn(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = null;
        String[] valueItemList = value.toString().split(",");
        Predicate[] predicateInList = new Predicate[valueItemList.length];
        for (int i = 0; i < valueItemList.length; i++) {
            String valueItem = valueItemList[i].trim();
            Predicate predicateIn = criteriaBuilder.equal(root.get(key), valueItem);
            predicateInList[i] = predicateIn;
        }
        predicate = criteriaBuilder.or(predicateInList);
        return predicate;
    }

    /**
     * Builds the not equal in.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildNotEqualIn(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = null;
        String[] valueItemList = value.toString().split(",");
        Predicate[] predicateInList = new Predicate[valueItemList.length];
        for (int i = 0; i < valueItemList.length; i++) {
            String valueItem = valueItemList[i].trim();
            Predicate predicateIn = criteriaBuilder.notEqual(root.get(key), valueItem);
            predicateInList[i] = predicateIn;
        }
        predicate = criteriaBuilder.and(predicateInList);
        return predicate;
    }

    /**
     * Builds the like in.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildLikeIn(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = null;
        String[] valueItemList = value.toString().split(",");
        Predicate[] predicateInList = new Predicate[valueItemList.length];
        for (int i = 0; i < valueItemList.length; i++) {
            String valueItem = valueItemList[i].trim();
            Predicate predicateIn = criteriaBuilder.like(root.get(key), "%" + valueItem + "%");
            predicateInList[i] = predicateIn;
        }
        predicate = criteriaBuilder.or(predicateInList);
        return predicate;
    }

    /**
     * Builds the is null.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildIsNull(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = criteriaBuilder.isNull(root.get(key));
        return predicate;
    }

    /**
     * Builds the is not null.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param criteriaBuilder
     *            the criteria builder
     * @param key
     *            the key
     * @param value
     *            the value
     * @return the predicate
     */
    private static <T> Predicate buildIsNotNull(From< ? , ? > root, CriteriaBuilder criteriaBuilder, String key,
            Object value) {
        Predicate predicate = criteriaBuilder.isNotNull(root.get(key));
        return predicate;
    }

    /**
     * Gets the join type val.
     *
     * @param joinType
     *            the join type
     * @return the join type val
     */
    private static JoinType getJoinTypeVal(String joinType) {
        JoinType joinTypeVal = JoinType.INNER;
        if ("left".equals(joinType)) {
            joinTypeVal = JoinType.LEFT;
        } else if ("right".equals(joinType)) {
            joinTypeVal = JoinType.RIGHT;
        }
        return joinTypeVal;
    }

    /**
     * Creates the table joins.
     *
     * @param <T>
     *            the generic type
     * @param root
     *            the root
     * @param joinTable
     *            the join table
     * @param joinType
     *            the join type
     * @return the join
     */
    private static <T> Join< ? , ? > createTableJoins(Root<T> root, String joinTable, String joinType) {
        Join< ? , ? > rootAfterJoin;
        String[] joinTables = joinTable.toString().split(Pattern.quote("."));
        log.debug("createTableJoins - num_tables_join: [{}]", joinTables.length);
        if (joinTables.length > 0) {
            rootAfterJoin = root.join(joinTables[0], getJoinTypeVal(joinType));
            for (int j = 1; j < joinTables.length; j++) {
                rootAfterJoin = rootAfterJoin.join(joinTables[j], getJoinTypeVal(joinType));
            }
        } else {
            rootAfterJoin = root.join(joinTable, getJoinTypeVal(joinType));
        }
        return rootAfterJoin;
    }
}
