package com.gcs.jars.core.scheduler.models;

import org.quartz.Job;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class BaseScheduleInfo<TJob extends Job> {
    
    /** The id. */
    protected Integer id;
    
    /** The job. */
    protected Class<TJob> jobType;
}
