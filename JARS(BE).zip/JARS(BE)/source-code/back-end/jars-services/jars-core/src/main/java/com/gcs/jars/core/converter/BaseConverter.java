/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 3, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.converter;

import org.modelmapper.ModelMapper;

/**
 * The Class BaseConverter.
 */
public abstract class BaseConverter<TEntity, TDto> {

    /** The model mapper. */
    protected ModelMapper modelMapper;

    /**
     * Instantiates a new base converter.
     */
    protected BaseConverter() {
        this.modelMapper = new ModelMapper();
    }

    /**
     * To dto.
     *
     * @param entity
     *            the entity
     * @return the t dto
     */
    public abstract TDto toDto(TEntity entity);

    /**
     * To entity.
     *
     * @param dto
     *            the dto
     * @return the t entity
     */
    public abstract TEntity toEntity(TDto dto);

    /**
     * To entity.
     *
     * @param dto the dto
     * @param entity the entity
     */
    public abstract void toEntity(TDto dto, TEntity entity);
}
