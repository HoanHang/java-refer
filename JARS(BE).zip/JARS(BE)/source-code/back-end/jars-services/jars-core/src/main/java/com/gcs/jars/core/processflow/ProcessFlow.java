package com.gcs.jars.core.processflow;

import java.util.function.Consumer;

/**
 * The Interface ProcessFlow.
 */
public interface ProcessFlow {
    /**
     * Gets the name.
     *
     * @return the name
     */
    String getName();

    /**
     * Execute.
     */
    ProcessResult execute();
    
    /**
     * Execute async.
     */
    void executeAsync();

    /**
     * Register sequence.
     *
     * @param sequence
     *            the sequence
     */
    void registerSequence(ProcessSequence sequence);
    
    /**
     * Register exception handling.
     *
     * @param onException the on exception
     * @return the process step
     */
    ProcessFlow registerOnException(Consumer<Exception> onException);
}
