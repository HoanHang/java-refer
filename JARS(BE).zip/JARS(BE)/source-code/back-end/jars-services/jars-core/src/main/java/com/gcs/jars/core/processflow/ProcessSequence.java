package com.gcs.jars.core.processflow;

public interface ProcessSequence {
    /**
     * Gets the name.
     *
     * @return the name
     */
    String getName();
    
    /**
     * Execute.
     *
     * @return the process result
     */
    ProcessResult execute();

    /**
     * Register step.
     *
     * @param step
     *            the step
     */
    void registerStep(ProcessStep step);
}
