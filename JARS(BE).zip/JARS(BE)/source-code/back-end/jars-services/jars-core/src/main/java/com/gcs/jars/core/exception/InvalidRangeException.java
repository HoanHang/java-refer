/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.exception;

/**
 * The Class InvalidRangeException.
 */
public class InvalidRangeException extends UserDefinedException {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 6685619807980525738L;

    /**
     * Constructor.
     *
     * @param errorCode
     *            the error code
     * @param errorText
     *            the error text
     */
    public InvalidRangeException(final String errorCode, final String errorText) {
        super(errorCode, errorText);
    }

    /**
     * The Constructor.
     *
     * @param errorCode
     *            the error code
     * @param errorText
     *            the error text
     * @param cause
     *            the cause
     */
    public InvalidRangeException(final String errorCode, final String errorText, final Throwable cause) {
        super(errorCode, errorText, cause);
    }
}
