package com.gcs.jars.core.repository;

public class Operator {
    public static final String EQUAL = "eq";
    public static final String NOT_EQUAL = "neq";
    public static final String LIKE = "like";
    public static final String NOT_LIKE = "notLike";
    public static final String LESS_THAN = "lt";
    public static final String LESS_OR_EQUAL = "le";
    public static final String GREATER_THAN = "gt";
    public static final String GREATER_OR_EQUAL = "ge";
    public static final String EQUAL_IN = "eqIn";
    public static final String NOT_EQUAL_IN = "notEqIn";
    public static final String LIKE_IN = "likeIn";
    public static final String IS_NULL = "isNull";
    public static final String IS_NOT_NULL = "isNotNull";
    public static final String COUNT_GREATER_OR_EQUAL = "countGe"; 
}
