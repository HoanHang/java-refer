package com.gcs.jars.core.scheduler;

import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;

import org.quartz.Job;
import org.quartz.Trigger;

import com.gcs.jars.core.scheduler.models.IntervalScheduleInfo;

public abstract class IntervalJobScheduler<TJob extends Job, TScheduleInfo extends IntervalScheduleInfo<TJob>>
        extends BaseJobScheduler<TJob, TScheduleInfo> {

    /**
     * {@inheritDoc}
     * @see com.gcs.jars.core.scheduler.BaseJobScheduler#createTrigger(com.gcs.jars.core.scheduler.models.BaseScheduleInfo, java.lang.String, java.lang.String)
     */
    @Override
    protected Trigger createTrigger(TScheduleInfo scheduleInfo, String triggerName, String triggerGroup) {
        Trigger trigger = newTrigger()
                .withSchedule(simpleSchedule().withIntervalInSeconds(scheduleInfo.getIntervalSecond()).repeatForever())
                .build();
        return trigger;
    }
}
