/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.logging;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * The Class LogAspect.
 */
@Aspect
@Component
public class LogAspect {

    /**
     * Inject into a method which is marked with InjectLog annotation.
     */
    @Pointcut("@annotation(com.gcs.jars.core.logging.InjectLog)")
    public void injectIntoMarked() {
        // Handle annotation from log
    }

    /**
     * Log before.
     *
     * @param joinPoint
     *            the join point
     */
    @Before("injectIntoMarked()")
    public void logBefore(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        InjectLog config = signature.getMethod().getAnnotation(InjectLog.class);
        Logger log = LoggerFactory.getLogger(joinPoint.getTarget().getClass());
        
        if (config.logEnter() && log.isDebugEnabled()) {
            log.debug("{} <- Enter", joinPoint.getSignature().getName());
        }
        if (config.logParams() && joinPoint.getArgs().length > 0) {
            log.debug("{} - Params:  {}", joinPoint.getSignature().getName(), Arrays.toString(joinPoint.getArgs()));
        }
    }

    /**
     * Log after.
     *
     * @param joinPoint
     *            the join point
     */
    @AfterReturning(pointcut = "injectIntoMarked()")
    public void logAfter(JoinPoint joinPoint) {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        InjectLog config = signature.getMethod().getAnnotation(InjectLog.class);
        Logger log = LoggerFactory.getLogger(joinPoint.getTarget().getClass());
        
        if (!log.isDebugEnabled()) {
            return;
        }
        if (config.logLeave()) {
            log.debug("{} -> Leave", joinPoint.getSignature().getName());
        }
    }
}
