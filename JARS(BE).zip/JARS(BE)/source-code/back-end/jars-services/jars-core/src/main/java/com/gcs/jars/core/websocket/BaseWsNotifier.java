package com.gcs.jars.core.websocket;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;

public abstract class BaseWsNotifier<TSubject> {

    /**
     * Gets the subscription.
     *
     * @return the subscription
     */
    protected abstract String getSubscription();

    /** The message sender. */
    @Autowired
    private SimpMessagingTemplate messageSender;

    /**
     * Notify.
     *
     * @param subject the subject
     */
    public void notify(TSubject subject) {
        this.messageSender.convertAndSend("/topic/" + this.getSubscription(), subject);
    }
}
