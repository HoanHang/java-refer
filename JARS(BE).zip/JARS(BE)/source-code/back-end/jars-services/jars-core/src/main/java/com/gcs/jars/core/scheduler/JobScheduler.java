package com.gcs.jars.core.scheduler;

import org.quartz.Job;

import com.gcs.jars.core.scheduler.models.BaseScheduleInfo;

public interface JobScheduler<TJob extends Job, TScheduleInfo extends BaseScheduleInfo<TJob>> {

    /**
     * Schedule job.
     *
     * @param scheduleInfo
     *            the schedule
     */
    void scheduleJob(TScheduleInfo scheduleInfo);
}
