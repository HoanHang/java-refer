package com.gcs.jars.core.processflow;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class BaseOutputProcessStep<TContext, TOut> extends BaseProcessStep<TContext>
        implements ProcessOutputStep<TOut> {

    /** The out data. */
    protected TOut outData = null;

    /**
     * Instantiates a new base process step.
     *
     * @param inName
     *            the in name
     * @param inContext
     *            the in context
     */
    protected BaseOutputProcessStep(String inName, TContext inContext) {
        super(inName, inContext);
        this.name = inName;
        this.context = inContext;
    }
}
