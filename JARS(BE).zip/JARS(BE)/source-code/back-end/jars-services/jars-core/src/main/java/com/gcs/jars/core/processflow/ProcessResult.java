package com.gcs.jars.core.processflow;

import com.gcs.jars.core.exception.UserDefinedException;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString()
public class ProcessResult {

    /** The process name. */
    private String processName;

    /** The has success. */
    private boolean isSuccess;

    /** The error. */
    private UserDefinedException error;
    
    /**
     * Instantiates a new process result.
     *
     * @param inProcessName the in process name
     */
    ProcessResult(String inProcessName) {
        this.processName = inProcessName;
        this.isSuccess = true;
    }
}
