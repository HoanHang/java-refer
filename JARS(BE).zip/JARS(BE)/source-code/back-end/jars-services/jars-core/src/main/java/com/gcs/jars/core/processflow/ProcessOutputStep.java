package com.gcs.jars.core.processflow;

public interface ProcessOutputStep<TOut> extends ProcessStep {
    /**
     * Gets the out data.
     *
     * @return the out data
     */
    TOut getOutData();
}
