/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 5, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.gcs.jars.core.converter.BaseConverter;
import com.gcs.jars.core.dto.BaseDTO;
import com.gcs.jars.core.dto.ResponseTemplate;
import com.gcs.jars.core.dto.SearchResultDTO;
import com.gcs.jars.core.entity.BaseEntity;
import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.service.BaseDataService;
import com.gcs.jars.core.util.CollectionUtil;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@NoArgsConstructor
@Slf4j
public abstract class BaseController<TId, TEntity extends BaseEntity<TId>, TDto extends BaseDTO<TId>, TRepo extends BaseRepository<TEntity, TId>, TCvt extends BaseConverter<TEntity, TDto>, TSvc extends BaseDataService<TId, TEntity, TDto, TRepo, TCvt>> {

    /** The service. */
    @Autowired
    protected TSvc dataService;

    /**
     * Gets the all items.
     *
     * @return the all items
     */
    protected ResponseEntity<Object> getAllItems() {
        List<TDto> dtoList = this.dataService.findAll();
        if (!CollectionUtil.isNullOrEmpty(dtoList)) {
            log.debug("Found [{}] items", dtoList.size());
        }
        return new ResponseEntity<>(dtoList, HttpStatus.OK);
    }

    /**
     * Search items.
     *
     * @param searchCondition
     *            the search condition
     * @return the response entity
     */
    protected ResponseEntity<Object> searchItems(SearchCondition searchCondition) {
        SearchResultDTO<TDto> searchResult = this.dataService.findByCriteria(searchCondition);
        log.debug("Total_items=[{}]", searchResult.getTotalItems());
        return new ResponseEntity<>(searchResult, HttpStatus.OK);
    }

    /**
     * Gets the item.
     *
     * @param id
     *            the id
     * @return the item
     */
    protected ResponseEntity<Object> getItem(TId id) {
        TDto dto = this.dataService.findById(id);
        if (dto != null) {
            log.debug("Found item-ID=[{}]", id);
        }
        return new ResponseEntity<>(dto, HttpStatus.OK);
    }

    /**
     * Insert item.
     *
     * @param dto
     *            the dto
     * @return the response entity
     */
    protected ResponseEntity<Object> insertItem(TDto dto) {
        TDto newDto = this.dataService.insert(dto);
        log.debug("{}-ID=[{}] is created successfully", this.dataService.getEntityName(), dto.getIdentifier());
        return new ResponseEntity<>(newDto, HttpStatus.OK);
    }

    /**
     * Update item.
     *
     * @param dto
     *            the dto
     * @return the response entity
     */
    protected ResponseEntity<Object> updateItem(TDto dto) {
        TDto updatedDto = this.dataService.update(dto);
        log.debug("{}-ID=[{}] is updated successfully", this.dataService.getEntityName(), dto.getIdentifier());
        return new ResponseEntity<>(updatedDto, HttpStatus.OK);
    }

    /**
     * Delete item.
     *
     * @param id
     *            the id
     * @return the response entity
     */
    protected ResponseEntity<Object> deleteItem(TId id) {
        this.dataService.delete(id);
        ResponseTemplate response = new ResponseTemplate(HttpStatus.OK,
                String.format("%s-ID=[%d] is deleted successfully", this.dataService.getEntityName(), id));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Delete item list.
     *
     * @param listDto the list dto
     * @return the response entity
     */
    @InjectLog(logParams = false)
    protected ResponseEntity<Object> deleteItemList(List<TDto> listDto) {
        this.dataService.deleteList(listDto);
        ResponseTemplate response = new ResponseTemplate(HttpStatus.OK,
                String.format("%s - [%d] items is deleted successfully", this.dataService.getEntityName(),listDto.size()));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    /**
     * Update item list.
     *
     * @param listDto the list dto
     * @return the response entity
     */
    @InjectLog(logParams = false)
    protected ResponseEntity<Object> updateItemList(List<TDto> listDto) {
        this.dataService.updateList(listDto);
        ResponseTemplate response = new ResponseTemplate(HttpStatus.OK,
                String.format("%s - [%d] items are updated successfully", this.dataService.getEntityName(),listDto.size()));
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
