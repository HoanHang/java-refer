package com.gcs.jars.core.dto;

import java.io.Serializable;

public abstract class SerializableDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7076146911195661498L;

}
