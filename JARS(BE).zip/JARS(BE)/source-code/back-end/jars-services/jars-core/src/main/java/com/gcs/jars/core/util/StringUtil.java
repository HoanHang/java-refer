package com.gcs.jars.core.util;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class StringUtil {
    
    /**
     * Trim url.
     *
     * @param url the url
     * @return the string
     */
    public static String trimUrl(String url) {
        String adjustedUrl = url;
        if(url.endsWith("/")) {
            adjustedUrl = url.substring(0, url.length() - 1);
        }
        return adjustedUrl;
    }
}
