package com.gcs.jars.core.dto;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
public class SearchResultDTO<T extends SerializableDTO> implements Serializable {
    
    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8889916279528418133L;

    /** The items. */
    private List<T> items;
    
    /** The total items. */
    private Long totalItems;
}