/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.core.repository;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Condition.
 */
@Setter
@Getter
@NoArgsConstructor
public class Condition implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8421542667431354316L;

    /** The search key. */
    private String key;

    /** The search value of key. */
    private transient Object value;

    /** The search type, like eq, ge, gt, le, lt..... */
    private String operator;
    
    /** The data type (string, number, date). */
    private String type;
    
    /** The join table. */
    private String joinTable;
    
    /** The join type. */
    private String joinType;
}
