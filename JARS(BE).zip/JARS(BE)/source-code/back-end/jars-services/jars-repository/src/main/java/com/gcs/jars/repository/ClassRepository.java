/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam Nguyen           Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.Operator;
import com.gcs.jars.core.repository.PredicateBuilder;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.entity.AgentClass;
import com.gcs.jars.entity.Class;

/**
 * The Interface ClassRepository.
 */
@Repository
public interface ClassRepository extends BaseCodeRepository<Class, Integer> {

    /**
     * Find by branch id.
     *
     * @param branchId
     *            the branch id
     * @return the list
     */
    List<Class> findByBranchId(Integer branchId);

    /**
     * Find by branch id and is active.
     *
     * @param branchId
     *            the branch id
     * @param isActive
     *            the is active
     * @return the list
     */
    List<Class> findByBranchIdAndIsActive(Integer branchId, Boolean isActive);

    /**
     * Find by branch id and is active and class id in.
     *
     * @param branchId
     *            the branch id
     * @param isActive
     *            the is active
     * @param classIds
     *            the class ids
     * @return the list
     */
    List<Class> findByBranchIdAndIsActiveAndClassIdIn(Integer branchId, Boolean isActive, List<Integer> classIds);

    /**
     * Find by class status and last updated.
     *
     * @param classStatus
     *            the class status
     * @param lastUpdated
     *            the last updated
     * @return the list
     */
    List<Class> findByClassStatusInAndLastUpdatedLessThan(Integer[] classStatus, Date lastUpdated);

    /**
     * Delete by class status in and last updated less than.
     *
     * @param classStatus
     *            the class status
     * @param lastUpdated
     *            the last updated
     * @return the list
     */
    void deleteByClassStatusInAndLastUpdatedLessThan(Integer[] classStatus, Date lastUpdated);

    /**
     * Delete by class id in.
     *
     * @param classIds
     *            the class ids
     */
    void deleteByClassIdIn(List<Integer> classIds);

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.repository.BaseRepository#initSearchCondition(javax.persistence.criteria.Root,
     *      javax.persistence.criteria.CriteriaBuilder, javax.persistence.criteria.CriteriaQuery,
     *      com.gcs.jars.core.repository.SearchCondition)
     */
    @Override
    default List<Predicate> initSearchCondition(Root<Class> root, CriteriaBuilder criteriaBuilder,
            CriteriaQuery< ? > criteriaQuery, SearchCondition searchCondition) {
        List<Predicate> predicateList = PredicateBuilder.build(root, criteriaBuilder, searchCondition);
        for (Condition condition : searchCondition.getConditions()) {
            String operator = condition.getOperator();
            String joinTable = condition.getJoinTable();
            if (operator.equals(Operator.COUNT_GREATER_OR_EQUAL)) {
                Predicate predicate = null;
                if (!StringUtils.isEmpty(joinTable)) {
                    switch (joinTable) {
                    case "agentClasses":
                        predicate = PredicateBuilder.buildCountGreaterOrEqual(root, criteriaBuilder, criteriaQuery,
                                searchCondition, condition, AgentClass.class);
                        break;
                    default:
                        
                    }
                }
                if (predicate != null) {
                    predicateList.add(predicate);
                }
            }
        }
        return predicateList;
    }
}
