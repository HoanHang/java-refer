package com.gcs.jars.repository;

import java.util.Date;
import java.util.List;

import com.gcs.jars.entity.AttendanceHistory;

public interface AttendanceHistoryRepositoryCustom {

    /**
     * Find by start date and end date.
     *
     * @param startDate the start date
     * @param endDate the end date
     * @return the list
     */
    List<AttendanceHistory> findByStartDateAndEndDate(Date startDate, Date endDate);
}
