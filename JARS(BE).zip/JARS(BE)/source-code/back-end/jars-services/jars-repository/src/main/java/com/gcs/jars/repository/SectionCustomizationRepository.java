/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam Nguyen           Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.SectionCustomization;

/**
 * The Interface SectionCustomizationRepository.
 */
@Repository
public interface SectionCustomizationRepository extends BaseRepository<SectionCustomization, Integer> {

    /**
     * Find by section id and device id.
     *
     * @param sectionId
     *            the section id
     * @param deviceId
     *            the device id
     * @return the list
     */
    List<SectionCustomization> findBySectionIdAndDeviceId(Integer sectionId, Integer deviceId);

    /**
     * Find by location id and section id and device id.
     *
     * @param locationId
     *            the location id
     * @param sectionId
     *            the section id
     * @param deviceId
     *            the device id
     * @return the list
     */
    List<SectionCustomization> findByLocationIdAndSectionIdAndDeviceId(Integer locationId, Integer sectionId,
            Integer deviceId);

    /**
     * Find by section id in.
     *
     * @param sectionIds
     *            the section ids
     * @return the list
     */
    List<SectionCustomization> findBySectionIdIn(List<Integer> sectionIds);

    /**
     * Find by section id.
     *
     * @param sectionId
     *            the section id
     * @return the list
     */
    List<SectionCustomization> findBySectionId(Integer sectionId);

    /**
     * Find by device id.
     *
     * @param deviceId
     *            the device id
     * @return the list
     */
    List<SectionCustomization> findByDeviceId(Integer deviceId);

    /**
     * Count by section id.
     *
     * @param sectionId
     *            the section id
     * @return the long
     */
    Long countBySectionId(Integer sectionId);
}
