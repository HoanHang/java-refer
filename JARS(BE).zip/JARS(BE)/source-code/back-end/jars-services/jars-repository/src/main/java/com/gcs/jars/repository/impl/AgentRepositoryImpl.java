package com.gcs.jars.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gcs.jars.constant.ConditionDataType;
import com.gcs.jars.constant.ConditionOperator;
import com.gcs.jars.constant.core.CommonConstants;
import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.entity.Agent;
import com.gcs.jars.repository.AgentRepository;
import com.gcs.jars.repository.AgentRepositoryCustom;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AgentRepositoryImpl implements AgentRepositoryCustom {
    
    /** The agent repository. */
    @Autowired
    private AgentRepository agentRepository;

    /**
     * Find agents by branch id.
     *
     * @param branchId
     *            the branch id
     * @return the list
     */
    @InjectLog
    public List<Agent> findByBranchIdActive(Integer branchId) {
        List<Agent> expAgentList = new ArrayList<Agent>();

        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(CommonConstants.MAX_PAGE_SIZE); // All records
        searchCondition.setSortName("agentId");
        searchCondition.setSortDirection(false); // ASC

        // Condition branchId
        Condition condition = new Condition();
        condition.setKey("branchId");
        condition.setValue(branchId);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        condition.setJoinTable("location");
        searchCondition.getConditions().add(condition);

        // Condition isActive
        condition = new Condition();
        condition.setKey("isActive");
        condition.setValue(1);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        searchCondition.getConditions().add(condition);

        // Search Devices
        SearchResult<Agent> searchResult = this.agentRepository.findByCriteria(searchCondition);
        if (searchResult.getTotalItems() > 0) {
            expAgentList.addAll(searchResult.getPage().getContent());
        }
        log.debug("findByBranchIdActive - found [{}] agents", expAgentList.size());
        return expAgentList;
    }
}
