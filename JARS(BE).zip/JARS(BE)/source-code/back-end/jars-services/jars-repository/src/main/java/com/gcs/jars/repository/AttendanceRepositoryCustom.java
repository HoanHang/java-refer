package com.gcs.jars.repository;

import java.util.Date;
import java.util.List;

import com.gcs.jars.entity.Attendance;

public interface AttendanceRepositoryCustom {

    /**
     * Find by last sync time.
     *
     * @param lastSyncTime the last sync time
     * @return the list
     */
    List<Attendance> findByLastSyncTime(Date lastSyncTime);
}
