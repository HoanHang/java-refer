package com.gcs.jars.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gcs.jars.constant.core.CommonConstants;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.core.util.DateTimeUtil;
import com.gcs.jars.entity.AttendanceHistory;
import com.gcs.jars.repository.AttendanceHistoryRepository;
import com.gcs.jars.repository.AttendanceHistoryRepositoryCustom;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AttendanceHistoryRepositoryImpl implements AttendanceHistoryRepositoryCustom {

    /** The attendance history repository. */
    @Autowired
    private AttendanceHistoryRepository attendanceHistoryRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.repository.AttendanceHistoryRepositoryCustom#findByStartDateAndEndDate(java.util.Date,
     *      java.util.Date)
     */
    @Override
    public List<AttendanceHistory> findByStartDateAndEndDate(Date startDate, Date endDate) {
        List<AttendanceHistory> expAttendanceHistoryList = new ArrayList<AttendanceHistory>();
        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(CommonConstants.MAX_PAGE_SIZE); // All records
        searchCondition.setSortName("attendanceHistoryId");
        searchCondition.setSortDirection(false); // ASC

        // StartTime <= attendanceTime
        startDate = DateTimeUtil.setTime(startDate, 0, 0, 0);
        Condition condition = new Condition();
        condition.setKey("attendanceTime");
        condition.setValue(DateTimeUtil.toString(startDate, CommonConstants.DATE_TIME_FORMAT));
        condition.setOperator("gt");
        condition.setType("datetime");
        searchCondition.getConditions().add(condition);

        // attendanceTime <= endDate
        endDate = DateTimeUtil.setTime(endDate, 23, 59, 59);
        condition = new Condition();
        condition.setKey("attendanceTime");
        condition.setValue(DateTimeUtil.toString(endDate, CommonConstants.DATE_TIME_FORMAT));
        condition.setOperator("lt");
        condition.setType("datetime");
        searchCondition.getConditions().add(condition);

        // Search class
        SearchResult<AttendanceHistory> searchResult = this.attendanceHistoryRepository.findByCriteria(searchCondition);
        log.debug("findByStartDateAndEndDate - totalItems=[{}]", searchResult.getTotalItems());
        if (searchResult.getTotalItems() > 0) {
            expAttendanceHistoryList.addAll(searchResult.getPage().getContent());
        }
        log.debug("findByStartDateAndEndDate - found [{}] items", expAttendanceHistoryList.size());
        return expAttendanceHistoryList;
    }

}
