/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam Nguyen           Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import com.gcs.jars.entity.Section;

/**
 * The Interface SectionRepository.
 */
public interface SectionRepositoryCustom {

    /**
     * Find earliest by class id.
     *
     * @param classId
     *            the class id
     * @return the section
     */
    Section findEarliestByClassId(Integer classId);

    /**
     * Find by code and class code.
     *
     * @param code
     *            the code
     * @param classCode
     *            the class code
     * @return the section
     */
    Section findByCodeAndClassCode(String code, String classCode);
}
