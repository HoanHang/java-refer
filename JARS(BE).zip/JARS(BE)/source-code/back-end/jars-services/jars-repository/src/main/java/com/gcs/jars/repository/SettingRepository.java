package com.gcs.jars.repository;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.Setting;

@Repository
public interface SettingRepository extends BaseRepository<Setting, Integer> {
    
    /**
     * Gets the by param key.
     *
     * @param paramKey the param key
     * @return the by param key
     */
     Setting findByParamKey(String paramKey);
}
