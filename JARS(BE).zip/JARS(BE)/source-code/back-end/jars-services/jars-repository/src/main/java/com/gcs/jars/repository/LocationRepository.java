/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Hoan Hang          Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.entity.Location;

/**
 * The Interface LocationRepository.
 */
@Repository
public interface LocationRepository extends BaseCodeRepository<Location, Integer> {

    /**
     * Find by branch id.
     *
     * @param branchId
     *            the branch id
     * @return the list
     */
    List<Location> findByBranchId(Integer branchId);
}
