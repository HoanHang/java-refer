/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.entity.Branch;

/**
 * The Interface BranchRepository.
 */
@Repository
public interface BranchRepository extends BaseCodeRepository<Branch, Integer> {

    /**
     * Find by region id.
     *
     * @param regionId
     *            the region id
     * @return the list
     */
    List<Branch> findByRegionId(Integer regionId);
}
