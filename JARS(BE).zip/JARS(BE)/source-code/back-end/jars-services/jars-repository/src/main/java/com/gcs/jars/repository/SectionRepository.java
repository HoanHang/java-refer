/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam Nguyen           Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.entity.Section;

/**
 * The Interface SectionRepository.
 */
@Repository
public interface SectionRepository extends BaseCodeRepository<Section, Integer>, SectionRepositoryCustom {

    /**
     * Find by class id.
     *
     * @param classId
     *            the class id
     * @return the list
     */
    List<Section> findByClassId(Integer classId);
    
    /**
     * Find by class id in.
     *
     * @param classIds the class ids
     * @return the list
     */
    List<Section> findByClassIdIn(List<Integer> classIds);
}
