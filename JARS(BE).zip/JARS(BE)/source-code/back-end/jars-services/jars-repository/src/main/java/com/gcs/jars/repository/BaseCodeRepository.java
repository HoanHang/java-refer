package com.gcs.jars.repository;

import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.transaction.annotation.Transactional;

import com.gcs.jars.core.repository.BaseRepository;

@NoRepositoryBean
@Transactional
public interface BaseCodeRepository<T, TId> extends BaseRepository<T, TId> {
    
    /**
     * Find by code.
     *
     * @param code the code
     * @return the t
     */
    T findByCode(String code);
}
