/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.SyncJobHistory;

/**
 * The Interface SyncJobHistoryRepository.
 */
@Repository
public interface SyncJobHistoryRepository extends BaseRepository<SyncJobHistory, Long> {

    /**
     * Find by sync job id.
     *
     * @param syncJobId
     *            the sync job id
     * @return the list
     */
    List<SyncJobHistory> findBySyncJobId(Integer syncJobId);

    /**
     * Find by created on between.
     *
     * @param createdOnStart
     *            the created on start
     * @param createdOnEnd
     *            the created on end
     * @return the list
     */
    List<SyncJobHistory> findByCreatedOnBetween(Date createdOnStart, Date createdOnEnd);
    
    /**
     * Find by created on less than.
     *
     * @param createdOn the created on
     * @return the list
     */
    List<SyncJobHistory> findByCreatedOnLessThan(Date createdOn);
    
    /**
     * Delete by created on less than.
     *
     * @param createdOn the created on
     */
    void deleteByCreatedOnLessThan(Date createdOn);
    
    /**
     * Delete by sync job history id in.
     *
     * @param syncJobHistoryIds the sync job history ids
     */
    void deleteBySyncJobHistoryIdIn(List<Long> syncJobHistoryIds);
}
