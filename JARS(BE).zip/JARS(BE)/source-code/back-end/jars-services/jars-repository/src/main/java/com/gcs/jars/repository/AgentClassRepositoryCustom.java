package com.gcs.jars.repository;

import java.util.Date;
import java.util.List;

import com.gcs.jars.entity.AgentClass;

public interface AgentClassRepositoryCustom {

    /**
     * Find agent by last sync time and class id active.
     *
     * @param lastSyncTime
     *            the last sync time
     * @param classId
     *            the class id
     * @return the list
     */
    List<AgentClass> findByLastSyncTimeAndClassIdAndActive(Date lastSyncTime, Integer classId);

    /**
     * Find by last sync time and class id and location id and active.
     *
     * @param lastSyncTime
     *            the last sync time
     * @param classId
     *            the class id
     * @param locationId
     *            the location id
     * @return the list
     */
    List<AgentClass> findByLastSyncTimeAndClassIdAndLocationIdAndActive(Date lastSyncTime, Integer classId,
            Integer locationId);

}
