/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Nov 6, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import com.gcs.jars.entity.Fingerprint;

public interface FingerprintRepositoryCustom {
    
    /**
     * Find by agent status and ignore agent id.
     *
     * @param agentStatus the agent status
     * @return the list
     */
    List<Fingerprint> findByAgentStatus(Integer agentStatus);
}