package com.gcs.jars.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gcs.jars.constant.ConditionDataType;
import com.gcs.jars.constant.ConditionOperator;
import com.gcs.jars.constant.core.CommonConstants;
import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.core.util.DateTimeUtil;
import com.gcs.jars.entity.AgentClass;
import com.gcs.jars.repository.AgentClassRepository;
import com.gcs.jars.repository.AgentClassRepositoryCustom;
import com.microsoft.sqlserver.jdbc.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AgentClassRepositoryImpl implements AgentClassRepositoryCustom {

    /** The agent class repository. */
    @Autowired
    private AgentClassRepository agentClassRepository;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.repository.AgentClassRepositoryCustom#findByLastSyncTimeAndClassIdAndActive(java.util.Date,
     *      java.lang.Integer)
     */
    @InjectLog
    public List<AgentClass> findByLastSyncTimeAndClassIdAndActive(Date lastSyncTime, Integer classId) {
        List<AgentClass> expAgentList = new ArrayList<AgentClass>();
        String lastSyncTimeFormatted = "";
        if (lastSyncTime != null) {
            lastSyncTimeFormatted = DateTimeUtil.toString(lastSyncTime, CommonConstants.DATE_TIME_FORMAT);
        }

        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(CommonConstants.MAX_PAGE_SIZE); // All records
        searchCondition.setSortName("agentId");
        searchCondition.setSortDirection(false); // ASC

        // Condition classId
        Condition condition = new Condition();
        condition.setKey("classId");
        condition.setValue(classId);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        searchCondition.getConditions().add(condition);

        // Condition isActive
        condition = new Condition();
        condition.setKey("isActive");
        condition.setValue(1);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        searchCondition.getConditions().add(condition);

        // Condition LastUpdated
        if (!StringUtils.isEmpty(lastSyncTimeFormatted)) {
            condition = new Condition();
            condition.setKey("lastUpdated");
            condition.setValue(lastSyncTimeFormatted);
            condition.setOperator("gt");
            condition.setType("datetime");
            searchCondition.getConditions().add(condition);
        }

        // Search Devices
        SearchResult<AgentClass> searchResult = this.agentClassRepository.findByCriteria(searchCondition);
        log.info("findByLastSyncTimeAndClassIdAndActive - lastSyncTimeFormatted=[{}], classId=[{}], totalItems=[{}]",
                lastSyncTime, classId, searchResult.getTotalItems());
        if (searchResult.getTotalItems() > 0) {
            expAgentList.addAll(searchResult.getPage().getContent());
        }
        log.info("findByLastSyncTimeAndClassIdAndActive - found [{}] agents", expAgentList.size());
        return expAgentList;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.repository.AgentClassRepositoryCustom#findByLastSyncTimeAndClassIdAndLocationIdAndActive(java.util.Date,
     *      java.lang.Integer, java.lang.Integer)
     */
    @InjectLog
    public List<AgentClass> findByLastSyncTimeAndClassIdAndLocationIdAndActive(Date lastSyncTime, Integer classId,
            Integer locationId) {
        List<AgentClass> expAgentList = new ArrayList<AgentClass>();
        String lastSyncTimeFormatted = "";
        if (lastSyncTime != null) {
            lastSyncTimeFormatted = DateTimeUtil.toString(lastSyncTime, CommonConstants.DATE_TIME_FORMAT);
        }

        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(CommonConstants.MAX_PAGE_SIZE); // All records
        searchCondition.setSortName("agentId");
        searchCondition.setSortDirection(false); // ASC

        // Condition classId
        Condition condition = new Condition();
        condition.setKey("classId");
        condition.setValue(classId);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        searchCondition.getConditions().add(condition);

        // Condition isActive
        condition = new Condition();
        condition.setKey("isActive");
        condition.setValue(1);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        searchCondition.getConditions().add(condition);

        // Condition locationId
        condition = new Condition();
        condition.setKey("locationId");
        condition.setValue(locationId);
        condition.setOperator(ConditionOperator.EQUAL);
        condition.setType(ConditionDataType.NUMBER);
        condition.setJoinTable("agent");
        searchCondition.getConditions().add(condition);

        // Condition LastUpdated
        if (!StringUtils.isEmpty(lastSyncTimeFormatted)) {
            condition = new Condition();
            condition.setKey("lastUpdated");
            condition.setValue(lastSyncTimeFormatted);
            condition.setOperator("gt");
            condition.setType("datetime");
            searchCondition.getConditions().add(condition);
        }

        // Search Devices
        SearchResult<AgentClass> searchResult = this.agentClassRepository.findByCriteria(searchCondition);
        log.info(
                "findByLastSyncTimeAndClassIdAndLocationIdAndActive - lastSyncTimeFormatted=[{}], "
                        + "classId=[{}], locationId=[{}], totalItems=[{}]",
                lastSyncTime, classId, locationId, searchResult.getTotalItems());
        if (searchResult.getTotalItems() > 0) {
            expAgentList.addAll(searchResult.getPage().getContent());
        }
        log.info("findByLastSyncTimeAndClassIdAndLocationIdAndActive - found [{}] agents", expAgentList.size());
        return expAgentList;
    }
}
