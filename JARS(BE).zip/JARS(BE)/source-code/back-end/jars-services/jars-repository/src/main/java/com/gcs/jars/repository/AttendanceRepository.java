/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Hoan Hang          Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.Attendance;

/**
 * The Interface AttendanceRepository.
 */
@Repository
public interface AttendanceRepository extends BaseRepository<Attendance, Long>, AttendanceRepositoryCustom {

    /**
     * Find by agent id and section id.
     *
     * @param agentId
     *            the agent id
     * @param sectionId
     *            the section id
     * @return the attendance
     */
    Attendance findByAgentIdAndSectionId(Long agentId, Integer sectionId);

    /**
     * Find by agent id.
     *
     * @param agentId
     *            the agent id
     * @return the list
     */
    List<Attendance> findByAgentId(Long agentId);
    
    /**
     * Find by section id in.
     *
     * @param sectionIds the section ids
     * @return the list
     */
    List<Attendance> findBySectionIdIn(List<Integer> sectionIds);
    
    /**
     * Find by agent id in.
     *
     * @param agentIds the agent ids
     * @return the list
     */
    List<Attendance> findByAgentIdIn(List<Long> agentIds);
}
