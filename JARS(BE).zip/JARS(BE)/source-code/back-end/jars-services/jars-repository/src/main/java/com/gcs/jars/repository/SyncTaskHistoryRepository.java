/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.SyncTaskHistory;

/**
 * The Interface SyncTaskHistoryRepository.
 */
@Repository
public interface SyncTaskHistoryRepository extends BaseRepository<SyncTaskHistory, Long> {

    /**
     * Find by sync task id.
     *
     * @param syncTaskId
     *            the sync task id
     * @return the list
     */
    List<SyncTaskHistory> findBySyncTaskId(Integer syncTaskId);
    
    /**
     * Find by sync task id in.
     *
     * @param syncTaskIds the sync task ids
     * @return the list
     */
    List<SyncTaskHistory> findBySyncTaskIdIn(List<Integer> syncTaskIds);
}
