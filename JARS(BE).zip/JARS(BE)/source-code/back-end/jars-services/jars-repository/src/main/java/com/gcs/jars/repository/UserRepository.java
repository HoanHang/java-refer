/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.User;

/**
 * The Interface UserRepository.
 */
@Repository
public interface UserRepository extends BaseRepository<User, Long> {

    /**
     * Find by role id.
     *
     * @param roleId
     *            the role id
     * @return the list
     */
    List<User> findByRoleId(Integer roleId);
    
    /**
     * Find by user name.
     *
     * @param userName the user name
     * @return the user
     */
    User findByUserName(String userName);
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.core.repository.BaseRepository#useDistinct(javax.persistence.criteria.Root, javax.persistence.criteria.CriteriaBuilder, javax.persistence.criteria.CriteriaQuery)
     */
    default void useDistinct(Root<User> root, CriteriaBuilder criteriaBuilder, CriteriaQuery< ? > criteriaQuery) {
        criteriaQuery.distinct(true);   
    }
}
