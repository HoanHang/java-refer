package com.gcs.jars.repository.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.Operator;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.entity.Section;
import com.gcs.jars.repository.SectionRepository;
import com.gcs.jars.repository.SectionRepositoryCustom;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class SectionRepositoryImpl implements SectionRepositoryCustom {

    /** The section repository. */
    @Autowired
    private SectionRepository sectionRepository;

    /**
     * Find earliest by class id.
     *
     * @param classId
     *            the class id
     * @return the section
     */
    @InjectLog
    public Section findEarliestByClassId(Integer classId) {
        Section sectionFound = null;
        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(1); // All records
        searchCondition.setSortName("startDate");
        searchCondition.setSortDirection(false); // ASC

        // Condition branchId
        Condition condition = new Condition();
        condition.setKey("classId");
        condition.setValue(classId);
        condition.setOperator("eq");
        condition.setType("number");
        searchCondition.getConditions().add(condition);

        // Search Devices
        SearchResult<Section> searchResult = this.sectionRepository.findByCriteria(searchCondition);
        log.debug("findEarliestByClassId - totalItems=[{}]", searchResult.getTotalItems());
        if (searchResult.getTotalItems() > 0) {
            sectionFound = searchResult.getPage().getContent().get(0);
        }
        return sectionFound;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.repository.SectionRepositoryCustom#findByCodeAndClassCode(java.lang.String, java.lang.String)
     */
    @InjectLog
    public Section findByCodeAndClassCode(String code, String classCode) {
        Section sectionFound = null;
        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(1); // All records
        searchCondition.setSortName("startDate");
        searchCondition.setSortDirection(false); // ASC

        // Condition branchId
        Condition condition = new Condition();
        condition.setKey("code");
        condition.setValue(code);
        condition.setOperator(Operator.EQUAL);
        searchCondition.getConditions().add(condition);

        condition = new Condition();
        condition.setKey("code");
        condition.setValue(classCode);
        condition.setOperator(Operator.EQUAL);
        condition.setJoinTable("classInfo");
        searchCondition.getConditions().add(condition);

        // Search Devices
        SearchResult<Section> searchResult = this.sectionRepository.findByCriteria(searchCondition);
        log.debug("findByCodeAndClassCode - totalItems=[{}]", searchResult.getTotalItems());
        if (searchResult.getTotalItems() > 0) {
            sectionFound = searchResult.getPage().getContent().get(0);
        }
        return sectionFound;
    }
}
