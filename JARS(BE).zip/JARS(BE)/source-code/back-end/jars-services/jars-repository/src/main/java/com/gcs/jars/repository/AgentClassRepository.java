/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam Nguyen           Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.AgentClass;

/**
 * The Interface AgentClassRepository.
 */
@Repository
public interface AgentClassRepository extends BaseRepository<AgentClass, Long>, AgentClassRepositoryCustom {

    /**
     * Find by agent id and class id.
     *
     * @param agentId
     *            the agent id
     * @param classId
     *            the class id
     * @return the list
     */
    AgentClass findByAgentIdAndClassId(Long agentId, Integer classId);

    /**
     * Find by class id.
     *
     * @param classId
     *            the class id
     * @return the agent class
     */
    List<AgentClass> findByClassId(Integer classId);

    /**
     * Find by class id and is active.
     *
     * @param classId
     *            the class id
     * @param isActive
     *            the is active
     * @return the list
     */
    List<AgentClass> findByClassIdAndIsActive(Integer classId, Boolean isActive);

    /**
     * Query by class id.
     *
     * @param classId
     *            the class id
     * @return the list
     */
    @Query(value = "select a.CANDIDATE_CODE, a.AGENT_ID from AGENT_CLASS ac inner join AGENT a on ac.AGENT_ID=a.AGENT_ID where ac.CLASS_ID=:classId", nativeQuery = true)
    List<Object[]> queryByClassId(@Param("classId") Integer classId);

    /**
     * Count by class id and is active.
     *
     * @param classId
     *            the class id
     * @param isActive
     *            the is active
     * @return the long
     */
    Long countByClassIdAndIsActive(Integer classId, Boolean isActive);

    /**
     * Find by class id in.
     *
     * @param classIds
     *            the class ids
     * @return the list
     */
    List<AgentClass> findByClassIdIn(List<Integer> classIds);

    /**
     * Find by agent id.
     *
     * @param agentId
     *            the agent id
     * @return the list
     */
    List<AgentClass> findByAgentId(Long agentId);

    /**
     * Find by agent id in.
     *
     * @param agentIds
     *            the agent ids
     * @return the list
     */
    List<AgentClass> findByAgentIdIn(List<Long> agentIds);

    /**
     * Delete by class id.
     *
     * @param classId
     *            the class id
     * @return the long
     */
    Long deleteByClassId(Integer classId);
}
