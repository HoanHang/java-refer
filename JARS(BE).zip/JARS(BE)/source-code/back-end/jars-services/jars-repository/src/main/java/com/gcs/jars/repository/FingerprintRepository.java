/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.Fingerprint;

/**
 * The Interface FingerprintRepository.
 */
@Repository
public interface FingerprintRepository extends BaseRepository<Fingerprint, Long>, FingerprintRepositoryCustom {

    /**
     * Find by agent id.
     *
     * @param agentId
     *            the agent id
     * @return the list
     */
    List<Fingerprint> findByAgentId(Long agentId);
    
    /**
     * Count by agent id.
     *
     * @param agentId the agent id
     * @return the long
     */
    Long countByAgentId(Long agentId);
    
    /**
     * Find by agent id in.
     *
     * @param agentIds the agent ids
     * @return the list
     */
    List<Fingerprint> findByAgentIdIn(List<Long> agentIds);
    
    /**
     * Find by agent status.
     *
     * @param agentStatus the agent status
     * @return the list
     */
    List<Fingerprint> findByAgentStatus(Integer agentStatus);
}
