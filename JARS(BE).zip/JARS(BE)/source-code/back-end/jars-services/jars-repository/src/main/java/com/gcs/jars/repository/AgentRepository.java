/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam Nguyen           Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.gcs.jars.entity.Agent;

/**
 * The Interface AgentRepository.
 */
@Repository
public interface AgentRepository extends BaseCodeRepository<Agent, Long>, AgentRepositoryCustom {

    /**
     * Find by location id.
     *
     * @param locationId
     *            the location id
     * @return the list
     */
    List<Agent> findByLocationId(Integer locationId);

    /**
     * Find by location id and agent status.
     *
     * @param locationId
     *            the location id
     * @param agentStatus
     *            the agent status
     * @return the list
     */
    List<Agent> findByLocationIdAndAgentStatus(Integer locationId, Integer agentStatus);

    /**
     * Find by agent type.
     *
     * @param agentType
     *            the agent type
     * @return the list
     */
    List<Agent> findByAgentType(Integer agentType);

    /**
     * Query by agent type.
     *
     * @param agentType
     *            the agent type
     * @return the list
     */
    @Query(value = "select CANDIDATE_CODE, AGENT_ID from AGENT", nativeQuery = true)
    List<Object[]> queryAll();

    /**
     * Query all with agent code.
     *
     * @return the list
     */
    @Query(value = "select AGENT_CODE, AGENT_ID from AGENT", nativeQuery = true)
    List<Object[]> queryAllWithAgentCode();

    /**
     * Find by agent status.
     *
     * @param agentStatus
     *            the agent status
     * @return the list
     */
    List<Agent> findByAgentStatus(Integer agentStatus);

    /**
     * Find by location id agent type and.
     *
     * @param locationid
     *            the locationid
     * @param agentType
     *            the agent type
     * @return the list
     */
    List<Agent> findByLocationIdAndAgentType(Integer locationid, Integer agentType);

    /**
     * Find by agent code.
     *
     * @param agentCode
     *            the agent code
     * @return the agent
     */
    Agent findByAgentCode(String agentCode);

    /**
     * Find by agent status in and last updated less than.
     *
     * @param classStatus
     *            the class status
     * @param lastUpdated
     *            the last updated
     * @return the list
     */
    List<Agent> findByAgentStatusInAndLastUpdatedLessThan(Integer[] classStatus, Date lastUpdated);

    /**
     * Delete by agent id in.
     *
     * @param agentIds
     *            the agent ids
     */
    void deleteByAgentIdIn(List<Long> agentIds);

    /**
     * Count by location id.
     *
     * @param locationId
     *            the location id
     * @return the long
     */
    Long countByLocationId(Integer locationId);

    /**
     * Count by location id and agent status.
     *
     * @param locationId
     *            the location id
     * @param agentStatus
     *            the agent status
     * @return the long
     */
    Long countByLocationIdAndAgentStatus(Integer locationId, Integer agentStatus);
}
