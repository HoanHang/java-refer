/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Hoan Hang          Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import org.springframework.stereotype.Repository;

import com.gcs.jars.entity.Region;

/**
 * The Interface RegionRepository.
 */
@Repository
public interface RegionRepository extends BaseCodeRepository<Region, Integer> {
    
}
