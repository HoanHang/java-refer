/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Nov 6, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gcs.jars.constant.core.CommonConstants;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.entity.Fingerprint;
import com.gcs.jars.repository.FingerprintRepository;
import com.gcs.jars.repository.FingerprintRepositoryCustom;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FingerprintRepositoryImpl implements FingerprintRepositoryCustom {
    
    /** The fingerprint repository. */
    @Autowired
    private FingerprintRepository fingerprintRepository;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.repository.FingerprintRepositoryCustom#findByAgentStatus(java.lang.Integer)
     */
    @Override
    public List<Fingerprint> findByAgentStatus(Integer agentStatus) {
        List<Fingerprint> list = new ArrayList<Fingerprint>();

        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(CommonConstants.MAX_PAGE_SIZE); // All records
        searchCondition.setSortName("fingerprintId");
        searchCondition.setSortDirection(false); // ASC

        // Condition isActive
        Condition condition = new Condition();
        condition.setKey("agentStatus");
        condition.setValue(agentStatus);
        condition.setOperator("eq");
        condition.setType("number");
        condition.setJoinTable("agent");
        condition.setJoinType("inner");
        searchCondition.getConditions().add(condition);

        // Search Devices
        log.debug("findByCriteria - seach...");
        SearchResult<Fingerprint> searchResult = this.fingerprintRepository.findByCriteria(searchCondition);
        if (searchResult.getTotalItems() != null && searchResult.getTotalItems() > 0) {
            log.debug("findByAgentStatus - totalItems=[{}]", searchResult.getTotalItems());
            list.addAll(searchResult.getPage().getContent());
        }
        log.debug("findByAgentStatus - found [{}] items", list.size());
        return list;
    }
}
