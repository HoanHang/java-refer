/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 1, 2019     ********            NAMNGUYEN           Create repository                  
 *                                                                                
 */
package com.gcs.jars.repository;

import org.springframework.stereotype.Repository;

import com.gcs.jars.entity.Alarm;
import com.gcs.jars.core.repository.BaseRepository;

/**
 * The Interface AlarmRepository.
 */
@Repository
public interface AlarmRepository extends BaseRepository<Alarm, Long> {

}
