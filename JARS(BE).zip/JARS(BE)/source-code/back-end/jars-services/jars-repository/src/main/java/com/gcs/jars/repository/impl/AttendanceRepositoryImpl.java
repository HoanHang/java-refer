package com.gcs.jars.repository.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gcs.jars.constant.core.CommonConstants;
import com.gcs.jars.core.repository.Condition;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.core.repository.SearchResult;
import com.gcs.jars.core.util.DateTimeUtil;
import com.gcs.jars.entity.Attendance;
import com.gcs.jars.repository.AttendanceRepository;
import com.gcs.jars.repository.AttendanceRepositoryCustom;
import com.microsoft.sqlserver.jdbc.StringUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AttendanceRepositoryImpl implements AttendanceRepositoryCustom {

    /** The attendance repository. */
    @Autowired
    private AttendanceRepository attendanceRepository;

    /**
     * {@inheritDoc}
     * @see com.gcs.jars.repository.AttendanceRepositoryCustom#findByLastSyncTime(java.util.Date)
     */
    @Override
    public List<Attendance> findByLastSyncTime(Date lastSyncTime) {
        List<Attendance> expAttendancetList = new ArrayList<Attendance>();
        String lastSyncTimeFormatted = "";
        if (lastSyncTime != null) {
            lastSyncTimeFormatted = DateTimeUtil.toString(lastSyncTime,CommonConstants.DATE_TIME_FORMAT);
        }

        SearchCondition searchCondition = new SearchCondition();
        searchCondition.setPage(1);
        searchCondition.setSize(CommonConstants.MAX_PAGE_SIZE); // All records
        searchCondition.setSortName("agentId");
        searchCondition.setSortDirection(false); // ASC

        // Condition LastUpdated
        if (!StringUtils.isEmpty(lastSyncTimeFormatted)) {
            Condition condition = new Condition();
            condition.setKey("attendanceTime");
            condition.setValue(lastSyncTimeFormatted);
            condition.setOperator("gt");
            condition.setType("datetime");
            searchCondition.getConditions().add(condition);
        }

        // Search class
        SearchResult<Attendance> searchResult = this.attendanceRepository.findByCriteria(searchCondition);
        log.debug("findByLastSyncTime - totalItems=[{}]", searchResult.getTotalItems());
        if (searchResult.getTotalItems() > 0) {
            expAttendancetList.addAll(searchResult.getPage().getContent());
        }
        log.debug("findByLastSyncTime - found [{}] items", expAttendancetList.size());
        return expAttendancetList;
    }

}
