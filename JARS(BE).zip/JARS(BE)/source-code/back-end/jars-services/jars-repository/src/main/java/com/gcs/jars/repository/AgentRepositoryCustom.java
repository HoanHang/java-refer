package com.gcs.jars.repository;

import java.util.List;

import com.gcs.jars.entity.Agent;

public interface AgentRepositoryCustom {
    
    /**
     * Find agents by branch id active.
     *
     * @param branchId the branch id
     * @return the list
     */
    List<Agent> findByBranchIdActive(Integer branchId);
}
