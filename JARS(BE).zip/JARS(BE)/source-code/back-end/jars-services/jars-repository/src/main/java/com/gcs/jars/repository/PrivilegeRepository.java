/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Hoan Hang          Initialize                  
 *                                                                                
 */
package com.gcs.jars.repository;

import org.springframework.stereotype.Repository;

import com.gcs.jars.core.repository.BaseRepository;
import com.gcs.jars.entity.Privilege;

/**
 * The Interface PrivilegeRepository.
 */
@Repository
public interface PrivilegeRepository extends BaseRepository<Privilege, Integer> {

}
