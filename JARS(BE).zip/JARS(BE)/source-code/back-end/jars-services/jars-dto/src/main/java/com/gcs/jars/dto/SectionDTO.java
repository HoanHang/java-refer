/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 * 
 * 
 * Description: The file class
 * 
 * Change history: 
 * Date             Defect#             Person             Comments
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam nguyen            Initialize 
 * 
 */

package com.gcs.jars.dto;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Section.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class SectionDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4823334576717033897L;

    /** The section ID. */
    private Integer sectionId;

    /** The code. */
    private String code;
    
    /** The name. */
    private String name;

    /** The class id. */
    private Integer classId;

    /** The Name of Class. */
    private String className;
    
    /** The branch id. */
    private Integer branchId;
    
    /** The branch name. */
    private String branchName;

    /** The Start Date. */
    private Date startDate;

    /** The From Time. */
    private Time fromTime;

    /** The End Time. */
    private Time endTime;

    /** The attendance duration. */
    private Integer attendanceDuration;

    /** The is active. */
    private Boolean isActive;

    /** The Last Update. */
    private Date lastUpdated;

    /** The SectionCustomization of Section. */
    private List<SectionCustomizationDTO> sectionCustomizations;
//    
//    /** The attendances. */
//    private List<AttendanceDTO> attendances;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.sectionId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.sectionId = id;
    }
}
