/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Role.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class RoleDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 318831807718728344L;

    /** The role id. */
    private Integer roleId;

    /** The name. */
    private String name;

    /** The description. */
    private String description;

    /** The users. */
    private List<UserDTO> users;

    /** The role privileges. */
    private List<RolePrivilegeDTO> rolePrivileges;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.roleId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.roleId = id;
    }
}
