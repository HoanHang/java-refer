/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            DUCPHAM            Add device entity and repository                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Device.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class DeviceDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7549192977292211379L;

    /** The device id. */
    private Integer deviceId;

    /** The branch id. */
    private Integer branchId;

    /** The Branch Name. */
    private String branchName;

    /** The region id. */
    private Integer regionId;

    /** The region name. */
    private String regionName;

    /** The code. */
    private String code;

    /** The device status. */
    private Integer deviceStatus;

    /** The IP address. */
    private String ipAddress;

    /** The port. */
    private Integer port;

    /** The description. */
    private String description;

    /** The description. */
    private Date lastUpdated;

    /** The last sync time. */
    private Date lastSyncTime;

    /** The last sync result. */
    private Integer lastSyncResult;

    // /** The Section Customization. */
    // private List<SectionCustomizationDTO> sectionCustomizations;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.deviceId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.deviceId = id;
    }

}
