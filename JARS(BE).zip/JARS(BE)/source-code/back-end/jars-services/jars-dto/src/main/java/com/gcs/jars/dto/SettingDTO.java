package com.gcs.jars.dto;

import java.util.Date;

import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class SettingDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The setting id. */
    private Integer settingId;

    /** The param key. */
    private String paramKey;

    /** The param value. */
    private String paramValue;

    /** The date type. */
    private Integer dateType;

    /** The data format. */
    private String dataFormat;

    /** The data length. */
    private Integer dataLength;

    /** The value min. */
    private String valueMin;

    /** The value max. */
    private String valueMax;

    /** The value list. */
    private String valueList;

    /** The created on. */
    private Date createdOn;

    /** The updated on. */
    private Date updatedOn;

    /** The description. */
    private String description;

    /**
     * {@inheritDoc}
     * @see com.gcs.jars.core.dto.BaseDTO#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.settingId;
    }

    /**
     * {@inheritDoc}
     * @see com.gcs.jars.core.dto.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    public void setIdentifier(Integer id) {
        this.settingId = id;
    }
    
}
