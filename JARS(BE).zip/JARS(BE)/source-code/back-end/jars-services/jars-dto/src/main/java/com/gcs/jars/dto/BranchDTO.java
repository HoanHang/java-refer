/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Branch.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class BranchDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7028133354354362723L;

    /** The template category id. */
    private Integer branchId;

    /** The region id. */
    private Integer regionId;
    
    /** The region name. */
    private String regionName;

    /** The name. */
    private String name;

    /** The brief code. */
    private String code;

    /** The is active. */
    private Boolean isActive;

    /** The last updated. */
    private Date lastUpdated;

//    /** The devices. */
//    private List<DeviceDTO> devices;

//    /** The locations. */
//    private List<LocationDTO> locations;

//    /** The classes. */
//    private List<ClassDTO> classes;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.branchId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.branchId = id;
    }
}
