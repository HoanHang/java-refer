package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AttendanceHistoryDTO extends BaseDTO<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7056923018279375868L;

    /** The attendance history id. */
    private Long attendanceHistoryId;
    
    /** The agent id. */
    private Long agentId;
    
    /** The attendance time. */
    private Date attendanceTime;
   
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Long getIdentifier() {
        return this.attendanceHistoryId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Long id) {
        this.attendanceHistoryId = id;
    }
}
