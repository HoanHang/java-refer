/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Sep 18, 2019     ********            Tuan Vu            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.sql.Time;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class PurgeJobDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5744192642950614588L;

    /** The sync job id. */
    private Integer purgeJobId;
    
    /** The interval times. */
    private Integer intervalTimes;
    
    /** The start time. */
    private Time startTime;
    
    /** The class information expired. */
    private Integer classInformationExpired;
    
    /** The class information expired unit (day, month, year). */
    private Integer classInformationExpiredUnit;
    
    /** The agent information expired. */
    private Integer agentInformationExpired;
    
    /** The agent information expired unit (day, month, year). */
    private Integer agentInformationExpiredUnit;
    
    /** The job history expired. */
    private Integer jobHistoryExpired;
    
    /** The job history expired unit (day, month, year). */
    private Integer jobHistoryExpiredUnit;
    
    /** The archived data expired. */
    private Integer archivedDataExpired;
    
    /** The archived data expired unit (day, month, year). */
    private Integer archivedDataExpiredUnit;
        
    /** The data archiving folder. */
    private String dataArchivingFolder;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.purgeJobId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.purgeJobId = id;
    }
}
