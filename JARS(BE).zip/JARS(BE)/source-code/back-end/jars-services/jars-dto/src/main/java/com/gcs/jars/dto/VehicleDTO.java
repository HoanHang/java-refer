/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class User.
 */
@Getter
@Setter
@ToString(callSuper = true)
public class VehicleDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7549192977292211379L;

    /** The user id. */
    private Integer vehicleId;
    
    /** The name. */
    private String name;
    
    /** The register number. */
    private String registerNumber;

    /** The user name. */
    private String ownerName;

    /** The is created on. */
    private Date createOn;

    /** The last updated. */
    private Date lastUpdated;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.vehicleId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.vehicleId = id;
    }
}
