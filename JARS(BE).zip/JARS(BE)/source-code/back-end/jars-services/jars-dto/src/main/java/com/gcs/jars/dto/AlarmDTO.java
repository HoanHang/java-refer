/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 1, 2019     ********            Nam Nguyen            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Alarm.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AlarmDTO extends BaseDTO<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -575566339502709647L;

    /** The alarm ID. */
    private Long alarmId;

    /** The alarm state. */
    private Integer alarmState;

    /** The alarm code. */
    private Integer alarmCode;
    
    /** The alarm text. */
    private String alarmText;

    /** The occurred on. */
    private Date occurredOn;

    /** The updated on. */
    private Date updatedOn;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Long getIdentifier() {
        return this.alarmId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Long id) {
        this.alarmId = id;
    }
}
