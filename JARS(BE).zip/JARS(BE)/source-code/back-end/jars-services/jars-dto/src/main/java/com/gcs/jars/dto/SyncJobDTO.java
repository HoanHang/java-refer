/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.sql.Time;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Sync_Job.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class SyncJobDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5744192642950614588L;

    /** The sync job id. */
    private Integer syncJobId;
    
    /** The code. */
    private String code;

    /** The description. */
    private String description;

    /** The source. */
    private String source;

    /** The destination. */
    private String destination;

    /** The sync status. */
    private Integer syncStatus;

    /** The trigger mode. */
    private Integer triggerMode;

    /** The last sync time. */
    private Date lastSyncTime;
    
    /** The last execute time. */
    private Date lastExecuteTime;

    /** The last sync result. */
    private Integer lastSyncResult;
    
    /** The interval times. */
    private Integer intervalTimes;
    
    /** The start time. */
    private Time startTime;
    
    /** The is force sync. */
    private Boolean isForceSync = false;

//    /** The sync job histories. */
//    private List<SyncJobHistoryDTO> syncJobHistories;

//    /** The sync tasks. */
//    private List<SyncTaskDTO> syncTasks;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.syncJobId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.syncJobId = id;
    }
}
