/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class AgentClass.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AgentClassDTO extends BaseDTO<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5027195062552297177L;

    /** The agent class id. */
    private Long agentClassId;

    /** The agent id. */
    private Long agentId;

    /** The agent name. */
    private String agentName;
    
    /** The agent candidate code. */
    private String agentCandidateCode;

    /** The class id. */
    private Integer classId;

    /** The name of class. */
    private String className;

    /** The is active. */
    private Boolean isActive;
    
    /** The last updated. */
    private Date lastUpdated;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Long getIdentifier() {
        return this.agentClassId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Long id) {
        this.agentClassId = id;
    }
}
