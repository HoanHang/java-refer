/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            DUCPHAM            Add device entity and repository                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Attendance.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AttendanceDTO extends BaseDTO<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5402283220556820579L;

    /** The attendance id. */
    private Long attendanceId;
    
    /** The agent id. */
    private Long agentId;
    
    /** The section id. */
    private Integer sectionId;
   
    /** The attendance time. */
    private Date attendanceTime;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Long getIdentifier() {
        return this.attendanceId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Long id) {
        this.attendanceId = id;
    }
}
