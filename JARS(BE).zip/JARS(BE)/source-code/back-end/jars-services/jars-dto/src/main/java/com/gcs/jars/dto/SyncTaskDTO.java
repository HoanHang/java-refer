/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class SyncTaskDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -8413711108245093521L;

    /** The sync task id. */
    private Integer syncTaskId;

    /** The sync job id. */
    private Integer syncJobId;
    
    /** The device id. */
    private Integer deviceId;

    /** The device code. */
    private String deviceCode;

    /** The sync status. */
    private Integer syncStatus;
    
    /** The last sync time. */
    private Date lastSyncTime;
    
    /** The last execute time. */
    private Date lastExecuteTime;

    /** The last sync result. */
    private Integer lastSyncResult;

//    /** The sync task histories. */
//    private List<SyncTaskHistoryDTO> syncTaskHistories;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.syncTaskId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.syncTaskId = id;
    }
}
