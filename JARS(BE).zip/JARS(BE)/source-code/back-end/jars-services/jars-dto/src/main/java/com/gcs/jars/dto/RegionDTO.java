package com.gcs.jars.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Region.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class RegionDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8687439016758835706L;

    /** The Region ID. */
    private Integer regionId;

    /** The code. */
    private String code;

    /** The Name. */
    private String name;

    /** Is Active. */
    private Boolean isActive;

    /** The Update Mode. */
    private Date lastUpdated;

    /** The templates. */
    private List<BranchDTO> branches;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.regionId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.regionId = id;
    }
}
