/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 * 
 * @author nampn.nh
 * 
 * Description: The file class
 * 
 * Change history: 
 * Date             Defect#             Person             Comments
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam nguyen            Initialize 
 * 
 */
package com.gcs.jars.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Class.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class ClassDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4079830113108998406L;

    /** The class id. */
    private Integer classId;

    /** The branch id. */
    private Integer branchId;

    /** The Name of Branch. */
    private String branchName;

    /** The name. */
    private String name;

    /** The agent id. */
    private Long agentId;

    /** The Code. */
    private String code;

    /** The Trainer Code. */
    private String trainerCode;

    /** The trainer name. */
    private String trainerName;

    /** The Start Date. */
    private Date startDate;

    /** The End Date. */
    private Date endDate;

    /** The attendee assignment. */
    private Integer attendeeAssignment;

    /** The Class Status. */
    private Integer classStatus;

    /** The class type. */
    private String classType;

    /** The no of trainees. */
    private Integer noOfTrainees;

    /** The check dummy mode. */
    private Integer checkDummyMode;

    /** is_active. */
    private Boolean isActive;

    /** last_updated. **/
    private Date lastUpdated;

    /** The has setting devices. */
    private Boolean hasSettingDevices = false;

    /** The sections. */
    private List<SectionDTO> sections;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.classId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.classId = id;
    }
}
