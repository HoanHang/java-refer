/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class User.
 */
@Getter
@Setter
@ToString(callSuper = true)
public class UserDTO extends BaseDTO<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -4591795761934258183L;

    /** The user id. */
    private Long userId;

    /** The role id. */
    private Integer roleId;
    
    /** The name of Role. */
    private String roleName;
    
    /** The regions: Key: regionId, values: regionName */
    private Map<Integer, String> regions;
    
    /** The branches: Key: branchId, values: branchName */
    private Map<Integer, String> branches;
    
    /** The name. */
    private String name;

    /** The user name. */
    private String userName;

    /** The is created on. */
    private Date createdOn;

    /** The is active. */
    private Boolean isActive;

    /** The last updated. */
    private Date lastUpdated;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Long getIdentifier() {
        return this.userId;
    }
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Long id) {
        this.userId = id;
    }
}
