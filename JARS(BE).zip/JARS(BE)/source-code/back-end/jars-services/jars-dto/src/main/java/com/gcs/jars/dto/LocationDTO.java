/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 * 
 * 
 * Description: The file class
 * 
 * Change history: 
 * Date             Defect#             Person             Comments
 * -------------------------------------------------------------------------------
 * Aug 1, 2019     ********            Nam nguyen            Initialize 
 * 
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Location.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class LocationDTO extends BaseDTO<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7802555372554083268L;

    /**  The Location ID. */
    private Integer locationId;

    /** The branch id. */
    private Integer branchId;

    /** The Name of Branch. */
    private String branchName;
    
    /** The Code. */
    private String code;

    /** The Name. */
    private String name;

    /** Is Active. */
    private Boolean isActive;

    /** The last updated. */
    private Date lastUpdated;
    
    /** The total agents. */
    private Integer totalAgents;

//    /** The Agent. */
//    private List<AgentDTO> agents;
//
//    /** The section customizations. */
//    private List<SectionCustomizationDTO> sectionCustomizations;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Integer getIdentifier() {
        return this.locationId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Integer id) {
        this.locationId = id;
    }
}
