/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.gcs.jars.core.dto.BaseDTO;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * The Class Agent.
 */
@Getter
@Setter
@ToString(callSuper = true)
@NoArgsConstructor
public class AgentDTO extends BaseDTO<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 329656292376843343L;

    /** The agent id. */
    private Long agentId;
    
    /** The region id. */
    private Integer regionId;
    
    /** The region name. */
    private String regionName;
    
    /** The branch id. */
    private Integer branchId;
    
    /** The branch name. */
    private String branchName;
    
    /** The location id. */
    private Integer locationId;

    /** The Name of Location. */
    private String locationName;
    
    /** The location code. */
    private String locationCode;

    /** The name. */
    private String name;

    /** id_card_number. */
    private String idCardNumber;

    /** The brief cadidate_code. */
    private String code;

    /** The agent code. */
    private String agentCode;

    /** The agent type. */
    private Integer agentType;
    
    /** The agent status. */
    private Integer agentStatus;
    
    /** The dob. */
    private Date dateOfBirth;
    
    /** The sex. */
    private Integer sex;
    
    /** The is dummy. */
    private Boolean isDummy;
    
    /** The dummy with. */
    private String dummyWith;

    /** The is active. */
    private Boolean isActive;

    /** The license info. */
    private String licenseInfo;

    /** The last updated. */
    private Date lastUpdated;

    /** The fingerprint status. */
    private Integer fingerprintStatus;
    
    /** The checking status. */
    private Integer checkingStatus;
    
    /** The marking code. */
    private String markingCode;
    
//    /** The finger prints. */
//    private List<FingerprintDTO> fingerprints;
    
//    /** The agent classes. */
//    private List<AgentClassDTO> agentClasses;
//    
//    /** The attendances. */
//    private List<AttendanceDTO> attendances;
//    
//    /** The attendance histories. */
//    private List<AttendanceHistoryDTO> attendanceHistories;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#getIdentifier()
     */
    @Override
    @JsonIgnore
    public Long getIdentifier() {
        return this.agentId;
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.dto.base.BaseDTO#setIdentifier(java.lang.Object)
     */
    @Override
    @JsonIgnore
    public void setIdentifier(Long id) {
        this.agentId = id;
    }
}
