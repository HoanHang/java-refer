/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 27, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.controller;

import java.util.Date;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gcs.jars.common.converter.VehicleConverter;
import com.gcs.jars.common.service.VehicleDataService;
import com.gcs.jars.constant.ErrorCodes;
import com.gcs.jars.core.controller.BaseController;
import com.gcs.jars.core.dto.ResponseTemplate;
import com.gcs.jars.core.repository.SearchCondition;
import com.gcs.jars.dto.VehicleDTO;
import com.gcs.jars.entity.Vehicle;
import com.gcs.jars.repository.VehicleRepository;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/vehicle-management")
@Slf4j
public class VehicleController
        extends BaseController<Integer, Vehicle, VehicleDTO, VehicleRepository, VehicleConverter, VehicleDataService> {
	
    /**
     * Gets the all vehicle.
     *
     * @return the all vehicle
     */
    @GetMapping(value = "/vehicle")
    public ResponseEntity<Object> getAllVehicle() {
        return this.getAllItems();
    }
    
    /**
     * Search vehicle.
     *
     * @param searchCondition the search condition
     * @return the response entity
     */
    @PostMapping(value = "/vehicles/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> searchVehicle(@RequestBody SearchCondition searchCondition) {
        return this.searchItems(searchCondition);
    }
    
    /**
     * Insert vehicle.
     *
     * @param dto the dto
     * @return the response entity
     */
    @PostMapping(value = "/vehicles", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> insertVehicle(@RequestBody VehicleDTO dto) {
    	VehicleDTO existVehicle = this.dataService.findByRegisterNumber(dto.getRegisterNumber());
        if (existVehicle != null) {
            log.warn("updateVehicle - found other vehicle with the same code");
            return new ResponseEntity<>(new ResponseTemplate(HttpStatus.BAD_REQUEST, ErrorCodes.DUPLICATE_DEVICE_ID),
                    HttpStatus.BAD_REQUEST);
        }
        dto.setLastUpdated(new Date());
        return this.insertItem(dto);
    }

    /**
     * Update vehicle.
     *
     * @param dto the dto
     * @return the response entity
     */
    @PutMapping(value = "/vehicles", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> updateVehicle(@RequestBody VehicleDTO dto) {
        log.debug("Update Item to : [{}]", dto);
        return this.updateItem(dto);
    }

    
    /**
     * Delete vehicle.
     *
     * @param id the id
     * @return the response entity
     */
    @DeleteMapping(value = "/vehicles/{id}")
    public ResponseEntity<Object> deleteVehicle(@PathVariable("id") Integer id) {
        return this.deleteItem(id);
    }
    
    /**
     * Delete many devices
     * 
     * @param listDevices
     * @return
     */
    @PutMapping(value = "/vehicles/delete", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> deleteDeviceList(@RequestBody List<VehicleDTO> listVehicles) {
        // Delete devices
        log.debug("foud [" + listVehicles.size() + "] items want delete");
        return this.deleteItemList(listVehicles);
    }

}
