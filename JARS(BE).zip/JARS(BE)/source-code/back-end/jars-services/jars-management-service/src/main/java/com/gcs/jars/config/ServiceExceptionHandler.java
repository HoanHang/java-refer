/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 3, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.config;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.gcs.jars.core.exception.handler.BaseExceptionHandler;

import lombok.NoArgsConstructor;

@NoArgsConstructor
@ControllerAdvice
public class ServiceExceptionHandler extends BaseExceptionHandler {

}
