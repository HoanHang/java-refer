/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.common.converter;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.gcs.jars.core.converter.BaseConverter;
import com.gcs.jars.core.logging.InjectLog;
import com.gcs.jars.dto.VehicleDTO;
import com.gcs.jars.entity.Vehicle;

import lombok.NoArgsConstructor;

/**
 * The Class UserConverter.
 */
@NoArgsConstructor
@Service
public class VehicleConverter extends BaseConverter<Vehicle, VehicleDTO> {
    /**
     * To dto.
     *
     * @param entity
     *            the entity
     * @return the template DTO
     */
    @Override
    @InjectLog(logParams = false)
    public VehicleDTO toDto(Vehicle entity) {
    	VehicleDTO dto = new VehicleDTO();
    	dto.setVehicleId(entity.getVehicleId());
        dto.setName(entity.getName());
        dto.setOwnerName(entity.getOwnerName());
        dto.setCreateOn(new Date());
        dto.setRegisterNumber(entity.getRegisterNumber());
        dto.setLastUpdated(entity.getLastUpdated());
        return dto;
        //return this.modelMapper.map(entity, VehicleDTO.class);
    }

    /**
     * To entity.
     *
     * @param dto
     *            the dto
     * @return the t entity
     */
    @Override
    @InjectLog
    public Vehicle toEntity(VehicleDTO dto) {
    	Vehicle entity = new Vehicle();
    	entity.setVehicleId(dto.getVehicleId());
    	entity.setName(dto.getName());
    	entity.setOwnerName(dto.getOwnerName());
    	entity.setRegisterNumber(dto.getRegisterNumber());
    	entity.setCreateOn(new Date());
    	entity.setName(dto.getName());
    	entity.setLastUpdated(dto.getLastUpdated());
        return entity;
        //return this.modelMapper.map(dto, Vehicle.class);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.fas.common.converter.base.BaseConverter#toEntity(java.lang.Object, java.lang.Object)
     */
    @Override
    @InjectLog(logParams = false)
    public void toEntity(VehicleDTO dto, Vehicle entity) {
    	entity.setName(dto.getName());
    	entity.setRegisterNumber(dto.getRegisterNumber());
    	entity.setOwnerName(dto.getOwnerName());
    	entity.setCreateOn(dto.getCreateOn());
    	entity.setLastUpdated(new Date());
    }
}
