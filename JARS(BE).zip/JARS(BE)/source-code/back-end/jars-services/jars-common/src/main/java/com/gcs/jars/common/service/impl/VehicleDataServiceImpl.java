/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.common.service.impl;

import org.springframework.stereotype.Service;

import com.gcs.jars.common.converter.VehicleConverter;
import com.gcs.jars.common.service.VehicleDataService;
import com.gcs.jars.core.service.BaseDataServiceImpl;
import com.gcs.jars.dto.VehicleDTO;
import com.gcs.jars.entity.Vehicle;
import com.gcs.jars.repository.VehicleRepository;

import lombok.NoArgsConstructor;

@NoArgsConstructor
@Service
public class VehicleDataServiceImpl extends BaseDataServiceImpl<Integer, Vehicle, VehicleDTO, VehicleRepository, VehicleConverter>
        implements VehicleDataService {
    /**
     * Gets the entity name.
     *
     * @return the entity name
     */
    @Override
    public String getEntityName() {
        return "Vehicle";
    }
    
    
    /**
     * Find by register number.
     *
     * @param registerNumber the register number
     * @return the vehicle DTO
     */
    @Override
    public VehicleDTO findByRegisterNumber(String registerNumber) {
    	VehicleDTO dto = null;
    	Vehicle entity = this.repository.findByRegisterNumber(registerNumber);
        if (entity != null) {
            dto = this.converter.toDto(entity);
        }
        return dto;
    }
}
