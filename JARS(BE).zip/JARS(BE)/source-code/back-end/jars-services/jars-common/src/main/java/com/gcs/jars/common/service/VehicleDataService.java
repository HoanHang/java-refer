package com.gcs.jars.common.service;

import com.gcs.jars.common.converter.VehicleConverter;
import com.gcs.jars.core.service.BaseDataService;
import com.gcs.jars.dto.VehicleDTO;
import com.gcs.jars.entity.Vehicle;
import com.gcs.jars.repository.VehicleRepository;

public interface VehicleDataService extends BaseDataService<Integer, Vehicle, VehicleDTO, VehicleRepository, VehicleConverter>{
	
	/**
	 * Find by register number.
	 *
	 * @param registerNumber the register number
	 * @return the vehicle DTO
	 */
	VehicleDTO findByRegisterNumber(String registerNumber);
    	
}
