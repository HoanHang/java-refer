/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class AgentClass.
 */
@Entity
@Table(name = "AGENT_CLASS")
@Getter
@Setter
@NoArgsConstructor
public class AgentClass extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 4301710366580243400L;

    /** The agent class id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AGENT_CLASS_ID", unique = true)
    @CsvBindByName(column = "AGENT_CLASS_ID")
    private Long agentClassId;

    /** The agent id. */
    @Column(name = "AGENT_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "AGENT_ID")
    private Long agentId;

    /** The agent. */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "AGENT_ID")
    private Agent agent;

    /** The class id. */
    @Column(name = "CLASS_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "CLASS_ID")
    private Integer classId;

    /** The class info. */
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "CLASS_ID")
    private Class classInfo;

    /** The is active. */
    @Column(name = "IS_ACTIVE")
    @CsvBindByName(column = "IS_ACTIVE")
    private Boolean isActive;

    /** The last updated. */
    @Column(name = "LAST_UPDATED")
    @CsvBindByName(column = "LAST_UPDATED")
    private Date lastUpdated;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.agentClassId;
    }

    /**
     * Instantiates a new agent class.
     *
     * @param agentClassId
     *            the agent class id
     */
    public AgentClass(Long agentClassId) {
        this.agentClassId = agentClassId;
    }
}
