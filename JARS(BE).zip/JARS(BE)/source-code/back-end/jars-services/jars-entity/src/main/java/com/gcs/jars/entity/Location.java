/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 * 
 * 
 * Description: The file class
 * 
 * Change history: 
 * Date             Defect#             Person             Comments
 * -------------------------------------------------------------------------------
 * Aug 1, 2019     ********            Nam nguyen            Initialize 
 * 
 */
package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Location.
 */
@Entity
@Table(name = "LOCATION")
@Getter
@Setter
@NoArgsConstructor
public class Location extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1558505129172937077L;

    /** The Location ID */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "LOCATION_ID", unique = true)
    private Integer locationId;

    /** The branch id. */
    @Column(name = "BRANCH_ID", updatable = false, insertable = false)
    private Integer branchId;

    /** The branch. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "BRANCH_ID")
    private Branch branch;

    /** The Code. */
    @Column(name = "CODE", length = 12)
    private String code;

    /** The Name. */
    @Column(name = "NAME", length = 64)
    private String name;

    /** Is Active. */
    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    /** The last updated. */
    @Column(name = "LAST_UPDATED")
    private Date lastUpdated;

    /** The Agent. */
    @OneToMany(mappedBy = "location", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Agent> agents;

    /** The section customizations. */
    @OneToMany(mappedBy = "location", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SectionCustomization> sectionCustomizations;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.locationId;
    }

    /**
     * Instantiates a new location.
     *
     * @param locationId
     *            the location id
     */
    public Location(Integer locationId) {
        this.locationId = locationId;
    }
}
