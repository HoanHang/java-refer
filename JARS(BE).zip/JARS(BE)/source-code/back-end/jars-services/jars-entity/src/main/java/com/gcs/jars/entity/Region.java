package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "REGION")
@Getter
@Setter
@NoArgsConstructor
public class Region extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1742670895456012342L;

    /** The Region ID. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "REGION_ID", unique = true)
    private Integer regionId;

    /** The code. */
    @Column(name = "CODE", length = 12)
    private String code;

    /** The Name. */
    @Column(name = "NAME", length = 128)
    private String name;

    /** Is Active. */
    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    /** The Update Mode. */
    @Column(name = "LAST_UPDATED")
    private Date lastUpdated;

    /** The templates. */
    @OneToMany(mappedBy = "region", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Branch> branches;
    
    /**
     * {@inheritDoc}
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.regionId;
    }
    
    /**
     * Instantiates a new region.
     *
     * @param regionId the region id
     */
    public Region(Integer regionId) {
        this.regionId = regionId;
    }
}
