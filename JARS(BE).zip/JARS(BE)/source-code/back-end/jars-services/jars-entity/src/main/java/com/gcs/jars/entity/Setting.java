package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "SETTING")
@Getter
@Setter
@NoArgsConstructor
public class Setting  extends BaseEntity<Integer>{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1L;

    /** The setting id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SETTING_ID", unique = true)
    private Integer settingId;
    
    /** The param key. */
    @Column(name = "PARAM_KEY", length = 32)    
    private String paramKey;
    
    /** The param value. */
    @Column(name = "PARAM_VALUE", length = 255)
    private String paramValue;
    
    /** The date type. */
    @Column(name = "DATE_TYPE")
    private Integer dateType;
    
    /** The data format. */
    @Column(name = "DATA_FORMAT", length = 128)
    private String dataFormat;
    
    /** The data length. */
    @Column(name = "DATA_LENGTH")
    private Integer dataLength;
    
    /** The value min. */
    @Column(name = "VALUE_MIN", length = 128)
    private String valueMin;
    
    /** The value max. */
    @Column(name = "VALUE_MAX", length = 128)    
    private String valueMax;
    
    /** The value list. */
    @Column(name = "VALUE_LIST", length = 128)
    private String valueList;
    
    /** The created on. */
    @Column(name = "CREATED_ON")
    private Date createdOn;
    
    /** The updated on. */
    @Column(name = "UPDATED_ON")
    private Date updatedOn;
    
    /** The description. */
    @Column(name = "DESCRIPTION", length = 128)
    private String description;

    /**
     * {@inheritDoc}
     * @see com.gcs.jars.core.entity.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.settingId;
    }
     
}
