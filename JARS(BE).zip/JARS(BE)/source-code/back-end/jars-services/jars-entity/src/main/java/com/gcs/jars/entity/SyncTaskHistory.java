/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SyncTaskHistory.
 */
@Entity
@Table(name = "SYNC_TASK_HISTORY")
@Getter
@Setter
@NoArgsConstructor
public class SyncTaskHistory extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The sync task history id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SYNC_TASK_HISTORY_ID", unique = true)
    @CsvBindByName(column = "SYNC_TASK_HISTORY_ID")
    private Long syncTaskHistoryId;

    /** The sync task id. */
    @Column(name = "SYNC_TASK_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "SYNC_TASK_ID")
    private Integer syncTaskId;

    /** The sync task. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SYNC_TASK_ID")
    private SyncTask syncTask;

    /** The history level. */
    @Column(name = "HISTORY_LEVEL")
    @CsvBindByName(column = "HISTORY_LEVEL")
    private Integer historyLevel;

    /** The message. */
    @Column(name = "MESSAGE", length = 256)
    @CsvBindByName(column = "MESSAGE")
    private String message;

    /** The detail. */
    @Column(name = "DETAIL", length = 256)
    @CsvBindByName(column = "DETAIL")
    private String detail;

    /** The created on. */
    @Column(name = "CREATED_ON")
    @CsvBindByName(column = "CREATED_ON")
    private Date createdOn;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.syncTaskHistoryId;
    }
}
