/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Role_Privilege.
 */
@Entity
@Table(name = "ROLE_PRIVILEGE")
@Getter
@Setter
@NoArgsConstructor
public class RolePrivilege extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The role privilege id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ROLE_PRIVILEGE_ID", unique = true)
    private Integer rolePrivilegeId;

    /** The role id. */
    @Column(name = "ROLE_ID", updatable = false, insertable = false)
    private Integer roleId;
    
    /** The role. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ROLE_ID")
    private Role role;

    /** The privilege id. */
    @Column(name = "PRIVILEGE_ID", updatable = false, insertable = false)
    private Integer privilegeId;
    
    /** The privilege. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "PRIVILEGE_ID")
    private Privilege privilege;

    /**
     * {@inheritDoc}
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.rolePrivilegeId;
    }
}
