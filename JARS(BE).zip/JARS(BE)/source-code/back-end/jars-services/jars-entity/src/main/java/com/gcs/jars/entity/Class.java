/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 * 
 * @author nampn.nh
 * 
 * Description: The file class
 * 
 * Change history: 
 * Date             Defect#             Person             Comments
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam nguyen            Initialize 
 * 
 */
package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CLASS")
@Getter
@Setter
public class Class extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8961441889923803902L;

    /** The class id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CLASS_ID", unique = true)
    @CsvBindByName(column = "CLASS_ID")
    private Integer classId;

    /** The branch id. */
    @Column(name = "BRANCH_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "BRANCH_ID")
    private Integer branchId;

    /** The branch. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "BRANCH_ID")
    private Branch branch;
    
    /** The agent id. */
    @Column(name = "AGENT_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "AGENT_ID")
    private Long agentId;

    /** The agent. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "AGENT_ID", nullable = true)
    private Agent agent;

    /** The name. */
    @Column(name = "NAME", length = 128)
    @CsvBindByName(column = "NAME")
    private String name;

    /**  The Code. */
    @Column(name = "CODE", length = 12)
    @CsvBindByName(column = "CODE")
    private String code;

    /**  The Start Date. */
    @Column(name = "START_DATE")
    @CsvBindByName(column = "START_DATE")
    private Date startDate;

    /**  The End Date. */
    @Column(name = "END_DATE")
    @CsvBindByName(column = "END_DATE")
    private Date endDate;
    
    @Column(name = "ATTENDEE_ASSIGNMENT")
    @CsvBindByName(column = "ATTENDEE_ASSIGNMENT")
    private Integer attendeeAssignment;

    /** The has setting devices. */
    @Column(name = "HAS_SETTING_DEVICES")
    @CsvBindByName(column = "HAS_SETTING_DEVICES")
    private Boolean hasSettingDevices;
    
    /** The class type. */
    @Column(name = "CLASS_TYPE", length = 12)
    @CsvBindByName(column = "CLASS_TYPE")
    private String classType;
    
    /**  The Class Status. */
    @Column(name = "CLASS_STATUS")
    @CsvBindByName(column = "CLASS_STATUS")
    private Integer classStatus;

    /** The check dummy mode. */
    @Column(name = "CHECK_DUMMY_MODE")
    @CsvBindByName(column = "CHECK_DUMMY_MODE")
    private Integer checkDummyMode;

    /** is_active. */
    @Column(name = "IS_ACTIVE")
    @CsvBindByName(column = "IS_ACTIVE")
    private Boolean isActive;
    
    /** last_updated. **/
    @Column(name = "LAST_UPDATED")
    @CsvBindByName(column = "LAST_UPDATED")
    private Date lastUpdated;

    /** The sections. */
    @OneToMany(mappedBy = "classInfo", fetch = FetchType.EAGER, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Section> sections;

    /** The agent classes. */
    @OneToMany(mappedBy = "classInfo", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgentClass> agentClasses;

    /**
     * Instantiates a new class.
     */
    public Class() {
        this.hasSettingDevices = false;
    }
    
    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.classId;
    }

    /**
     * Instantiates a new class.
     *
     * @param classId
     *            the class id
     */
    public Class(Integer classId) {
        this.classId = classId;
    }
}
