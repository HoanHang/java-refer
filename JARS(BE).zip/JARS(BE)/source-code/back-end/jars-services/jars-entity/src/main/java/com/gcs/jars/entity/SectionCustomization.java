/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Template.
 */
@Entity
@Table(name = "SECTION_CUSTOMIZATION")
@Getter
@Setter
@NoArgsConstructor
public class SectionCustomization extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 7991936629524732601L;

    /** The section customization id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SECTION_CUSTOMIZATION_ID", unique = true)
    @CsvBindByName(column = "SECTION_CUSTOMIZATION_ID")
    private Integer sectionCustomizationId;

    /** The location id. */
    @Column(name = "LOCATION_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "LOCATION_ID")
    private Integer locationId;

    /** The location. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "LOCATION_ID", nullable = true)
    private Location location;

    /** The section id. */
    @Column(name = "SECTION_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "SECTION_ID")
    private Integer sectionId;

    /** The section. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SECTION_ID")
    private Section section;

    /** The device id. */
    @Column(name = "DEVICE_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "DEVICE_ID")
    private Integer deviceId;

    /** The device. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    /** The last updated. */
    @Column(name = "LAST_UPDATED")
    @CsvBindByName(column = "LAST_UPDATED")
    private Date lastUpdated;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.sectionCustomizationId;
    }
}
