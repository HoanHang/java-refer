/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "VEHICLE")
@Getter
@Setter
@NoArgsConstructor
public class Vehicle extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The vehicle id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "VEHICLE_ID", unique = true)
    private Integer vehicleId;

    /** The name. */
    @Column(name = "NAME", length = 64)
    private String name;

    /** The register number. */
    @Column(name = "REGISTER_NUMBER", length = 64)
    private String registerNumber;

    /** The owner name. */
    @Column(name = "OWNER_NAME")
    private String ownerName;

    /** The create on. */
    @Column(name = "CREATE_ON")
    private Date createOn;

    /** The last updated. */
    @Column(name = "LAST_UPDATED")
    private Date lastUpdated;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.vehicleId;
    }
    
    /**
     * Instantiates a new vehicle.
     *
     * @param vehicleId the vehicle id
     */
    public Vehicle(Integer vehicleId) {
        this.vehicleId = vehicleId;
    }
}
