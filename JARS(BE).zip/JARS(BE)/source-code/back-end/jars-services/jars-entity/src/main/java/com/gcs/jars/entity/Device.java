/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            DUCPHAM            Add device entity and repository                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Device.
 */
@Entity
@Table(name = "DEVICE")
@Getter
@Setter
@NoArgsConstructor
public class Device extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5768105504267131433L;

    /** The device id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "DEVICE_ID", unique = true)
    private Integer deviceId;

    /** The branch id. */
    @Column(name = "BRANCH_ID", updatable = false, insertable = false)
    private Integer branchId;

    /** The branch. */
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "BRANCH_ID")
    private Branch branch;

    /** The code. */
    @Column(name = "CODE", length = 12)
    private String code;

    /** The device status. */
    @Column(name = "DEVICE_STATUS")
    private Integer deviceStatus;

    /** The IP address. */
    @Column(name = "IP_ADDRESS", length = 16)
    private String ipAddress;

    /** The port. */
    @Column(name = "PORT")
    private Integer port;

    /** The description. */
    @Column(name = "DESCRIPTION", length = 256)
    private String description;

    /** The description. */
    @Column(name = "LAST_UPDATED")
    private Date lastUpdated;

    /** The Section Customization. */
    @OneToMany(mappedBy = "device", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SectionCustomization> sectionCustomizations;

    /** The sync tasks. */
    @OneToMany(mappedBy = "device", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SyncTask> syncTasks;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.deviceId;
    }

    /**
     * Instantiates a new device.
     *
     * @param deviceId
     *            the device id
     */
    public Device(Integer deviceId) {
        this.deviceId = deviceId;
    }
}
