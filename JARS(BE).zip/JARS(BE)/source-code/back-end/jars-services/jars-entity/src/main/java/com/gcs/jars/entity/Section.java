/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 * 
 * 
 * Description: The file class
 * 
 * Change history: 
 * Date             Defect#             Person             Comments
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            Nam nguyen            Initialize 
 * 
 */

package com.gcs.jars.entity;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Section.
 */
@Entity
@Table(name = "SECTION")
@Getter
@Setter
@NoArgsConstructor
public class Section extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The section ID. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SECTION_ID", unique = true)
    @CsvBindByName(column = "SECTION_ID")
    private Integer sectionId;

    /** The class id. */
    @Column(name = "CLASS_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "CLASS_ID")
    private Integer classId;

    /** The section class. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "CLASS_ID")
    @CsvBindByName(column = "CLASS_ID")
    private Class classInfo;

    /** The section code. */
    @Column(name = "SECTION_CODE")
    @CsvBindByName(column = "SECTION_CODE")
    private String code;
    
    /** The name. */
    @Column(name = "SECTION_NAME")
    @CsvBindByName(column = "SECTION_NAME")
    private String name;

    /** The Start Date. */
    @Column(name = "START_DATE")
    @CsvBindByName(column = "START_DATE")
    private Date startDate;

    /** The From Time. */
    @Column(name = "FROM_TIME")
    @CsvBindByName(column = "FROM_TIME")
    private Time fromTime;

    /** The End Time. */
    @Column(name = "END_TIME")
    @CsvBindByName(column = "END_TIME")
    private Time endTime;

    /** The attendance duration. */
    @Column(name = "ATTENDANCE_DURATION")
    @CsvBindByName(column = "ATTENDANCE_DURATION")
    private Integer attendanceDuration;

    /** The is active. */
    @Column(name = "IS_ACTIVE")
    @CsvBindByName(column = "IS_ACTIVE")
    private Boolean isActive;
    
    /** The Last Update. */
    @Column(name = "LAST_UPDATED")
    @CsvBindByName(column = "LAST_UPDATED")
    private Date lastUpdated;

    /** The SectionCustomization of Section. */
    @OneToMany(mappedBy = "section", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SectionCustomization> sectionCustomizations;

    /** The attendances. */
    @OneToMany(mappedBy = "section", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Attendance> attendances;
    
    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.sectionId;
    }
    
    /**
     * Instantiates a new section.
     *
     * @param sectionId the section id
     */
    public Section(Integer sectionId) {
        this.sectionId = sectionId;
    }
}
