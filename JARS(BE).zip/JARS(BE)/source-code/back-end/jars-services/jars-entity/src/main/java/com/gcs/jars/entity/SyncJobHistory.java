/**
 /**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class SyncJobHistory.
 */
@Entity
@Table(name = "SYNC_JOB_HISTORY")
@Getter
@Setter
@NoArgsConstructor
public class SyncJobHistory extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The sync job history id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SYNC_JOB_HISTORY_ID", unique = true)
    @CsvBindByName(column = "SYNC_JOB_HISTORY_ID")
    private Long syncJobHistoryId;

    /** The sync job id. */
    @Column(name = "SYNC_JOB_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "SYNC_JOB_ID")
    private Integer syncJobId;

    /** The sync job. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SYNC_JOB_ID")
    private SyncJob syncJob;

    /** The history level. */
    @Column(name = "HISTORY_LEVEL")
    @CsvBindByName(column = "HISTORY_LEVEL")
    private Integer historyLevel;

    /** The detail. */
    @Column(name = "DETAIL", length = 256)
    @CsvBindByName(column = "DETAIL")
    private String detail;

    /** The created on. */
    @Column(name = "CREATED_ON")
    @CsvBindByName(column = "CREATED_ON")
    private Date createdOn;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.syncJobHistoryId;
    }
    
    /**
     * Instantiates a new sync job history.
     *
     * @param syncJobId the sync job history id
     */
    public SyncJobHistory(Long syncJobHistoryId) {
        this.syncJobHistoryId = syncJobHistoryId;
    }
    
}
