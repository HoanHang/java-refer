/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 1, 2019     ********            Nam Nguyen            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Alarm.
 */
@Entity
@Table(name = "ALARM")
@Getter
@Setter
@NoArgsConstructor
public class Alarm extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The alarm Id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ALARM_ID", unique = true)
    private Long alarmId;

    /** The alarm state. */
    @Column(name = "ALARM_STATE")
    private Integer alarmState;
    
    /** The alarm code. */
    @Column(name = "ALARM_CODE")
    private Integer alarmCode;

    /** The alarm text. */
    @Column(name = "ALARM_TEXT", length = 512)
    private String alarmText;

    /** The occurred on. */
    @Column(name = "OCCURRED_ON")
    private Date occurredOn;

    /** The updated on. */
    @Column(name = "UPDATED_ON")
    private Date updatedOn;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.alarmId;
    }
}
