/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Sync_Task.
 */
@Entity
@Table(name = "SYNC_TASK")
@Getter
@Setter
@NoArgsConstructor
public class SyncTask extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The sync task id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SYNC_TASK_ID", unique = true)
    @CsvBindByName(column = "SYNC_TASK_ID")
    private Integer syncTaskId;

    /** The sync job id. */
    @Column(name = "SYNC_JOB_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "SYNC_JOB_ID")
    private Integer syncJobId;

    /** The sync job. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "SYNC_JOB_ID")
    private SyncJob syncJob;

    /** The source. */
    @Column(name = "DEVICE_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "DEVICE_ID")
    private Integer deviceId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "DEVICE_ID")
    private Device device;

    /** The sync status. */
    @Column(name = "SYNC_STATUS")
    @CsvBindByName(column = "SYNC_STATUS")
    private Integer syncStatus;
    
    /** The last sync time. */
    @Column(name = "LAST_SYNC_TIME")
    @CsvBindByName(column = "LAST_SYNC_TIME")
    private Date lastSyncTime;
    
    /** The last execute time. */
    @Column(name = "LAST_EXECUTE_TIME")
    @CsvBindByName(column = "LAST_EXECUTE_TIME")
    private Date lastExecuteTime;

    /** The last sync result. */
    @Column(name = "LAST_SYNC_RESULT")
    @CsvBindByName(column = "LAST_SYNC_RESULT")
    private Integer lastSyncResult;

    /** The sync task histories. */
    @OneToMany(mappedBy = "syncTask", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SyncTaskHistory> syncTaskHistories;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.syncTaskId;
    }
    
    /**
     * Instantiates a new sync task.
     *
     * @param syncTaskId the sync task id
     */
    public SyncTask(Integer syncTaskId) {
        this.syncTaskId = syncTaskId;
    }
}
