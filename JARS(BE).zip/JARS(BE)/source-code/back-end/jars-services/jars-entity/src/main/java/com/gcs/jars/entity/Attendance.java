/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 22, 2019     ********            DUCPHAM            Add device entity and repository                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Attendance.
 */
@Entity
@Table(name = "ATTENDANCE")
@Getter
@Setter
@NoArgsConstructor
public class Attendance extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -915433342502431853L;

    /** The attendance id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ATTENDANCE_ID", unique = true)
    @CsvBindByName(column = "ATTENDANCE_ID")
    private Long attendanceId;

    /** The agent id. */
    @Column(name = "AGENT_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "AGENT_ID")
    private Long agentId;

    /** The agent. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "AGENT_ID")
    private Agent agent;
    
    /** The section id. */
    @Column(name = "SECTION_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "SECTION_ID")
    private Integer sectionId;
    
    /** The section. */
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "SECTION_ID")
    private Section section;

    /** The attendance time. */
    @Column(name = "ATTENDANCE_TIME")
    @CsvBindByName(column = "ATTENDANCE_TIME")
    private Date attendanceTime;
    
    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.attendanceId;
    }
}
