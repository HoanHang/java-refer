/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Agent.
 */
@Entity
@Table(name = "AGENT")
@Getter
@Setter
@NoArgsConstructor
public class Agent extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5687905980203763574L;

    /** The agent id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "AGENT_ID", unique = true)
    @CsvBindByName(column = "AGENT_ID")
    private Long agentId;

    /** The location id. */
    @Column(name = "LOCATION_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "LOCATION_ID")
    private Integer locationId;

    /** The location. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "LOCATION_ID")
    private Location location;

    /** The name. */
    @Column(name = "NAME", length = 64)
    @CsvBindByName(column = "NAME")
    private String name;

    /** id_card_number. */
    @Column(name = "ID_CARD_NUMBER", length = 12)
    @CsvBindByName(column = "ID_CARD_NUMBER")
    private String idCardNumber;

    /** The brief cadidate_code. */
    @Column(name = "CANDIDATE_CODE", length = 12)
    @CsvBindByName(column = "CANDIDATE_CODE")
    private String code;

    /** The agent code. */
    @Column(name = "AGENT_CODE", length = 12)
    @CsvBindByName(column = "AGENT_CODE")
    private String agentCode;

    /** The agent type. */
    @Column(name = "AGENT_TYPE")
    @CsvBindByName(column = "AGENT_TYPE")
    private Integer agentType;

    /** The agent status. */
    @Column(name = "AGENT_STATUS")
    @CsvBindByName(column = "AGENT_STATUS")
    private Integer agentStatus;

    /** The dob. */
    @Column(name = "DATE_OF_BIRTH")
    @CsvBindByName(column = "DATE_OF_BIRTH")
    private Date dateOfBirth;

    /** The sex. */
    @Column(name = "SEX")
    @CsvBindByName(column = "SEX")
    private Integer sex;

    /** The is dummy. */
    @Column(name = "IS_DUMMY")
    @CsvBindByName(column = "IS_DUMMY")
    private Boolean isDummy;

    /** The dummy with. */
    @Column(name = "DUMMY_WITH", length = 12)
    @CsvBindByName(column = "DUMMY_WITH")
    private String dummyWith;

    /** The marking code. */
    @Column(name = "MARKING_CODE", length = 128)
    @CsvBindByName(column = "MARKING_CODE")
    private String markingCode;

    /** The is active. */
    @Column(name = "IS_ACTIVE")
    @CsvBindByName(column = "IS_ACTIVE")
    private Boolean isActive;

    /** The license info. */
    @Column(name = "LICENSE_INFO", length = 64)
    @CsvBindByName(column = "LICENSE_INFO")
    private String licenseInfo;

    /** The last updated. */
    @Column(name = "LAST_UPDATED")
    @CsvBindByName(column = "LAST_UPDATED")
    private Date lastUpdated;
    
    /** The classes. */
    @OneToMany(mappedBy = "agent", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Class> classes;
    
    /** The finger prints. */
    @OneToMany(mappedBy = "agent", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Fingerprint> fingerprints;

    /** The agent classes. */
    @OneToMany(mappedBy = "agent", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AgentClass> agentClasses;

    /** The attendances. */
    @OneToMany(mappedBy = "agent", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Attendance> attendances;

    /** The attendance histories. */
    @OneToMany(mappedBy = "agent", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<AttendanceHistory> attendanceHistories;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.agentId;
    }

    /**
     * Instantiates a new agent.
     *
     * @param agentId
     *            the agent id
     */
    public Agent(Long agentId) {
        this.agentId = agentId;
    }

    /**
     * Gets the fp name.
     *
     * @return the fp name
     */
    public String getFpName() {        
        //Get last 6 digits of IdCardNumber
        String idCard = StringUtils.right(this.getIdCardNumber(), 6);
        //Get agent first name of AgentName
        String agentFirstName = this.getName().substring(this.getName().lastIndexOf(" ") + 1);        
        return "9" + idCard + "#" + agentFirstName;
    }

}
