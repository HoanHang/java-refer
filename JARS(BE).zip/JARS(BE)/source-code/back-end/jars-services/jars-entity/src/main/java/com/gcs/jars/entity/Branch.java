/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Branch.
 */
@Entity
@Table(name = "BRANCH")
@Getter
@Setter
@NoArgsConstructor
public class Branch extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 1777829116015648034L;

    /** The template category id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "BRANCH_ID", unique = true)
    private Integer branchId;

    /** The region id. */
    @Column(name = "REGION_ID", updatable = false, insertable = false)
    private Integer regionId;

    /** The region. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "REGION_ID")
    private Region region;

    /** The name. */
    @Column(name = "NAME", length = 128)
    private String name;

    /** The brief code. */
    @Column(name = "CODE", length = 12)
    private String code;

    /** The is active. */
    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    /** The last updated. */
    @Column(name = "LAST_UPDATED")
    private Date lastUpdated;

    /** The devices. */
    @OneToMany(mappedBy = "branch", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Device> devices;

    /** The locations. */
    @OneToMany(mappedBy = "branch", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Location> locations;

    /** The classes. */
    @OneToMany(mappedBy = "branch", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Class> classes;

    /** The user branches. */
    @OneToMany(mappedBy = "branch", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<UserBranch> userBranches;
    
    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.branchId;
    }
    
    /**
     * Instantiates a new branch.
     *
     * @param branchId the branch id
     */
    public Branch(Integer branchId) {
        this.branchId = branchId;
    }
}
