package com.gcs.jars.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;
import com.opencsv.bean.CsvBindByName;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "ATTENDANCE_HISTORY")
@Getter
@Setter
@NoArgsConstructor
public class AttendanceHistory extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5641173405267998360L;

    /** The attendance history id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ATTENDANCE_HISTORY_ID", unique = true)
    @CsvBindByName(column = "ATTENDANCE_HISTORY_ID")
    private Long attendanceHistoryId;

    /** The agent id. */
    @Column(name = "AGENT_ID", updatable = false, insertable = false)
    @CsvBindByName(column = "AGENT_ID")
    private Long agentId;

    /** The agent. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "AGENT_ID")
    private Agent agent;
    
    /** The attendance time. */
    @Column(name = "ATTENDANCE_TIME")
    @CsvBindByName(column = "ATTENDANCE_TIME")
    private Date attendanceTime;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.attendanceHistoryId;
    }
}
