/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.entity;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The Class Sync_Job.
 */
@Entity
@Table(name = "SYNC_JOB")
@Getter
@Setter
@NoArgsConstructor
public class SyncJob extends BaseEntity<Integer> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 8107092578377879894L;

    /** The sync job id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SYNC_JOB_ID", unique = true)
    private Integer syncJobId;
    
    /** The code. */
    @Column(name = "CODE", length = 32)
    private String code;

    /** The description. */
    @Column(name = "DESCRIPTION", length = 128)
    private String description;

    /** The source. */
    @Column(name = "SOURCE", length = 8)
    private String source;

    /** The destination. */
    @Column(name = "DESTINATION", length = 8)
    private String destination;

    /** The sync status. */
    @Column(name = "SYNC_STATUS")
    private Integer syncStatus;

    /** The trigger mode. */
    @Column(name = "TRIGGER_MODE")
    private Integer triggerMode;

    /** The last sync time. */
    @Column(name = "LAST_SYNC_TIME")
    private Date lastSyncTime;
    
    /** The last execute time. */
    @Column(name = "LAST_EXECUTE_TIME")
    private Date lastExecuteTime;

    /** The last sync result. */
    @Column(name = "LAST_SYNC_RESULT")
    private Integer lastSyncResult;
    
    /** The interval times. */
    @Column(name = "INTERVAL_TIMES")
    private Integer intervalTimes;
    
    /** The start time. */
    @Column(name = "START_TIME")
    private Time startTime;

    /** The sync job histories. */
    @OneToMany(mappedBy = "syncJob", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SyncJobHistory> syncJobHistories;

    /** The sync tasks. */
    @OneToMany(mappedBy = "syncJob", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SyncTask> syncTasks;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.entity.base.BaseEntity#getIdentifier()
     */
    @Override
    public Integer getIdentifier() {
        return this.syncJobId;
    }
    
    /**
     * Instantiates a new sync job.
     *
     * @param syncJobId the sync job id
     */
    public SyncJob(Integer syncJobId) {
        this.syncJobId = syncJobId;
    }
    
}
