package com.gcs.jars.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.gcs.jars.core.entity.BaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "USER_BRANCH")
@Getter
@Setter
@NoArgsConstructor
public class UserBranch extends BaseEntity<Long> {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 6336691902919402794L;

    /** The user branch id. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_BRANCH_ID", unique = true)
    private Long userBranchId;

    /** The user id. */
    @Column(name = "USER_ID", updatable = false, insertable = false)
    private Long userId;

    /** The user. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "USER_ID")
    private User user;

    /** The branch id. */
    @Column(name = "BRANCH_ID", updatable = false, insertable = false)
    private Integer branchId;

    /** The branch. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "BRANCH_ID")
    private Branch branch;

    /**
     * {@inheritDoc}
     * 
     * @see com.gcs.jars.core.entity.BaseEntity#getIdentifier()
     */
    @Override
    public Long getIdentifier() {
        return this.userBranchId;
    }

}
