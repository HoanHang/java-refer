package com.gcs.jars.constant;

public class Constants {
    // Setting
    public static final Integer FIRST_ATTENDANCE_VALID = 0;
    public static final Integer DEFAULT_ATTENDANCE_VALID = 60;
    
    // Purge jobs
    public static final Integer PURGE_JOB_ID = 1;    
    public static final Integer PURGE_JOB_MIN_CONFIGURATION = 1;
    public static final Integer PURGE_JOB_MAX_CONFIGURATION = 65535;
    public static final String TIME_FORMAT_HH_MM_SS = "HH:mm:ss";
    public static final Integer JPA_MAX_PARAMETER = 1000;
    public static final Integer NUMBER_OF_DAY_IN_MONTH = 30;
    public static final Integer NUMBER_OF_DAY_IN_YEAR = 365;
}
