package com.gcs.jars.constant;

import com.gcs.jars.constant.core.CommonConstants;

public class ConditionOperator extends CommonConstants {
    // The search type, like eq, ge, gt, le, lt.....
    public static final String EQUAL = "eq";
    public static final String GREATER_THAN_OR_EQUAL = "ge";
    public static final String GREATER_THAN = "gt";
    public static final String LESS_THAN_OR_EQUAL = "le";
    public static final String LESS_THAN = "lt";
}
