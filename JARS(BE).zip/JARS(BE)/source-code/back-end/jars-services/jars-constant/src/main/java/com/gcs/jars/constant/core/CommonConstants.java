/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Aug 4, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.constant.core;

public class CommonConstants {
    public static final Integer NUM_CORES = Runtime.getRuntime().availableProcessors();
    public static final Integer NUM_THREADS = (NUM_CORES > 1 ? NUM_CORES * 3 : 10);
    public static final Integer HEX_FF = 0xFF;
    public static final String DATE_TIME_FORMAT = "dd-MM-yyyy HH:mm:ss";
    public static final String DATE_TIME_FORMAT_2 = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT = "dd/MM/yyyy";
    public static final String DATE_STRING_FORMAT = "dd-MM-yyyy";
    public static final String DATE_STRING_FORMAT_DIR = "dd-MM-yyyy-HH-mm-ss";
    public static final String TIME_FORMAT = "HH:mm";
    public static final Integer MAX_PAGE_SIZE = 999999999;
    // Archive purge data
    public static final String ARCHIVING_FOLDER_NAME = "DataArchiving";
    // name of generated csv 
    public static final String CSV_CLASS = "Class.csv"; 
    // CSV file extension
    public static final String CSV_FILE_EXTENSION = ".csv"; 
}
