package com.gcs.jars.constant;

public class HistoryMessages {
    // HISTORY MESSAGES
    public static final String START_JOB = "Start job %s by %s.";
    public static final String END_JOB = "End job %s successfully.";
    public static final String END_JOB_FAILED =
            "End Job %s with failure. Please follow instruction in alarm to recover.";

    public static final String START_SYNC_SEQUENCE = "Start syncing data from %s to %s.";
    public static final String FINISH_SYNC_SEQUENCE_SUCCESS = "Finish sync data from %s to %s successfully.";
    public static final String FINISH_SYNC_SEQUENCE_FAILURE = "Fail to sync data from %s to %s. %s";

    public static final String START_SYNC_TO_DEVICE_STEP = "Start syncing data from %s to device %s.";
    public static final String FINISH_SYNC_TO_DEVICE_STEP_SUCCESS =
            "Finish sync data from %s to device %s successfully.";
    public static final String FINISH_SYNC_TO_DEVICE_STEP_FAILURE = "Fail to sync data from %s to device %s. %s";

    public static final String START_SYNC_FROM_DEVICE_STEP = "Start syncing data from device %s to %s.";
    public static final String FINISH_SYNC_FROM_DEVICE_STEP_SUCCESS =
            "Finish sync data from device %s to %s successfully.";
    public static final String FINISH_SYNC_FROM_DEVICE_STEP_FAILURE = "Fail to sync data from device %s to %s. %s";

    public static final String UPDATED_AGENT_NAME = "Agent %s updated Name. from [%s] to [%s].";
    public static final String NUMBER_OF_AGENTS_UPDATED_ID_CARD_NO = "Number of agents updated Name. are %d.";

    public static final String AGENT_ADDED_ON_DEVICE_IS_NOT_EXIST =
            "Account with ID: %d does not exist in system and is NOT recorded in system.";
    
    public static final String CLASS_IS_NOT_BEFORE_START_DATE_ACCEPTANCE = "Class %s is not synced because it won't start within %d days";
    
    public static final String CLASS_IS_NOT_CONFIGURED_DEVICE = "Class %s is not synced because there's no device configured";

    // ALARMS
    public static final String ERROR_NOT_YET_CONNECT_DEVICE = "Not yet connect to device %s.";
    public static final String ERROR_CANNOT_CONNECT_DEVICE = "Cannot connect to device %s.";
    public static final String ERROR_CANNOT_CONNECT_CPD = "Cannot connect to CPD.";

    public static final String ERROR_START_FAILED_DUE_TO_OTHER_RUNNING =
            "[%s] Fail to start job. There is another data synchronization job running: [%s].";

    public static final String ERROR_OBJECT_MISSING_KEY = "Object %s is missing key values: %s.";
    
    public static final String ERROR_INVALID_OBJECT = "Received an invalid object: %s %s.";

    public static final String ERROR_DEVICE_OUT_OF_MEMORY =
            "[%s] Fail to sync data to device. Number of agents going to sync [%d] exceed device remaining capacity [%d].";

    public static final String ERROR_DUPLICATE_CLASSES_AT_THE_SAME_TIME =
            "[%s] Fail to sync data to device. There are classes start at the same time: %s";

    public static final String ERROR_MORE_AGENTS_DUPLICATED_FP =
            "[%s] Fail to sync data to device. More than one agents have the same fingerprint [%s]";
    
    public static final String ERROR_NOT_FOUND_AGENT_FROM_CUSTOM_DEVICE_LOCATION =
            "[%s] Fail to sync data to device. Not found any agents from configured locations";
    
    public static final String ERROR_PURGE_ARCHIVING_FOLDER_ACCESS =
            "Purge: the archiving folder does not exist or cannot be accessed.";
    public static final String ERROR_PURGE_ARCHIVING_FOLDER_SPACE =
            "Purge: the archiving folder does not have enough free space.";
    public static final String ERROR_PURGE_DATABASE =
            "Purge: action cannot be executed due to database error.";

}
