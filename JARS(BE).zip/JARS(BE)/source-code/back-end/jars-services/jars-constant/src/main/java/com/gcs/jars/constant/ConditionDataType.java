package com.gcs.jars.constant;

import com.gcs.jars.constant.core.CommonConstants;

public class ConditionDataType extends CommonConstants {
    // The data type (string, number, date).
    public static final String STRING = "string";
    public static final String NUMBER = "number";
    public static final String DATE = "date";
}
