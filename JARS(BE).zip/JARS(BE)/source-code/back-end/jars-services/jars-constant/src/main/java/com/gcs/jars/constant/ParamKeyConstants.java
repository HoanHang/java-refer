package com.gcs.jars.constant;

import com.gcs.jars.constant.core.CommonConstants;

public class ParamKeyConstants extends CommonConstants {
    public static final String CPD_AGENTS_URL = "cpd-agents-url";
    public static final String CPD_ATTENDANCE_URL = "cpd-attendance-url";
    public static final String CPD_CLASSES_URL = "cpd-classes-url";
    public static final String CPD_LOCATIONS_URL = "cpd-locations-url";
    public static final String CPD_TRAINEES_URL = "cpd-trainees-url";
    public static final String CPD_TRAINERS_URL = "cpd-trainers-url";
    public static final String EARLIER_ACCEPTANCE_DURATION = "earlier-acceptance-duration";
    public static final String MIT_MAPPING = "mit-mapping";
    
    // Purge expired data configuration
    public static final String INTERVAL_TIME = "interval-time";
    public static final String START_TIME = "start-time";
    public static final String CLASS_INFORMATION_EXPIRED = "class-information-expired";
    public static final String AGENT_INFORMATION_EXPIRED = "agent-information-expired";
    public static final String JOB_HISTORY_EXPIRED = "job-history-expired";
    public static final String DATA_ARCHIVING_FOLDER = "data-archiving-folder";
    public static final String ARCHIVED_DATA_EXPIRED = "archived-data-expired";
    public static final String DAYS_PER_MONTH = "days-per-month";
    public static final String DAYS_PER_YEAR = "days-per-year";
    
    // Days sync data configuration
    public static final String BEFORE_START_DATE_ACCEPTANCE = "before-start-date-acceptance";
    
    // Status
    public static final String CPD_ENUM_ACTIVE_STATUS = "cpd-enum-active-status";
    public static final String CPD_ENUM_TRAINER_TYPE = "cpd-enum-trainer-type";
    public static final String CPD_ENUM_FIXED_ATTENDEE = "cpd-enum-fixed-attendee";
    public static final String CPD_ENUM_CLASS_OPEN_STATUS = "cpd-enum-class-open-status";
    public static final String CPD_ENUM_CLASS_CANCEL_STATUS = "cpd-enum-class-cancel-status";
    public static final String CPD_ENUM_CHECK_DUMMY_ONLINE = "cpd-enum-check-dummy-online";
    public static final String CPD_ENUM_MALE_GENDER = "cpd-enum-male-gender";
    
    // Page size
    public static final String PAGE_SIZE = "page-size";
}
