/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.constant;

import com.gcs.jars.constant.core.CommonErrorCodes;

/**
 * The Class ErrorCodes.
 */
public class ErrorCodes extends CommonErrorCodes {
    public static final String ERROR_UNKNOW = "E0000000";
    public static final String DUPLICATE_IP_ADDRESS = "E1000010";
    public static final String DUPLICATE_IP_ADDRESS_PORT = "E1000011";
    public static final String DUPLICATE_DEVICE_ID = "E1000012";

    // ALARMS
    public static final String ERROR_CANNOT_CONNECT_CPD = "E1001101";
    public static final String ERROR_CANNOT_CONNECT_DEVICE = "E1001103";
    public static final String ERROR_START_FAILED_DUE_TO_OTHER_RUNNING = "E1002001";
    public static final String ERROR_OBJECT_MISSING_KEY = "E1003001";
    public static final String ERROR_DEVICE_OUT_OF_MEMORY = "E1004001";
    public static final String ERROR_DUPLICATE_CLASSES_AT_THE_SAME_TIME = "E1004004";
    public static final String ERROR_MORE_AGENTS_DUPLICATED_FP = "E1004005";
    public static final String ERROR_CANNOT_EDIT_DEVICE_WHEN_JOBS_ARE_RUNNING = "E1001041";
    public static final String ERROR_CANNOT_DELETE_DEVICE_WHEN_JOBS_ARE_RUNNING = "E1001042";    
    public static final String ERROR_PURGE_ARCHIVING_FOLDER_ACCESS = "E1002002";
    public static final String ERROR_PURGE_ARCHIVING_FOLDER_SPACE = "E1002003";
    public static final String ERROR_PURGE_DATABASE = "E1002004";
    public static final String ERROR_DUPLICATE_USERNAME = "E1001004";
    
    /**
     * Gets the alarm code.
     *
     * @param value
     *            the value
     * @return the alarm code
     */
    public static Integer getAlarmCode(String value) {
        return Integer.parseInt(value.substring(4));
    }
}
