/**
 * Copyright (C) 2019, GCS Ltd. All rights reserved. Proprietary and confidential.
 *                                                                                
 * Description: The file class                                                 
 *                                                                                
 * Change history:                                                                
 * Date             Defect#             Person             Comments               
 * -------------------------------------------------------------------------------
 * Jul 15, 2019     ********            Tuan Le            Initialize                  
 *                                                                                
 */
package com.gcs.jars.constant.core;

/**
 * The Class ErrorCodes.
 */
public class CommonErrorCodes {

    // Common
    public static final String INVALID_ARGUMENT = "E0000001";
    public static final String INVALID_RANGE = "E0000002";
    public static final String INVALID_FORMAT = "E0000003";
    public static final String NOT_FOUND = "E0000004";
    public static final String FORBIDDEN = "E0000005";
    public static final String NULL_POINTER = "E0000006";
    public static final String EXPORT_FAILED = "E0000007";
    public static final String ENCRYPTION_FAILED = "E000101";
    public static final String DECRYPTION_FAILED = "E000102";
    public static final String GENERIC = "E0000999";
    
    // Scheduling
    public static final String SCHEDULING_FAILED = "E000201";

    // SQL
    public static final String SQL_OPERATION_FAILED = "E0001001";

    // Email
    public static final String EMAIL_SEND_FAILED = "E0002001";

    // HTTP
    public static final String HTTP_REQUEST_FAILED = "E0003001";
}
